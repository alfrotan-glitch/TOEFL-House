import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';

export function ensureFirstInstallEnvironment(): void {
  const envPath = resolve(process.cwd(), '.env');
  if (existsSync(envPath)) return;

  try {
    execFileSync(process.execPath, [resolve(process.cwd(), 'scripts', 'ensure-first-install-env.mjs')], {
      stdio: 'inherit',
      env: process.env,
    });
  } catch {
    throw new Error('Unable to create first-install environment. Run the project bootstrap from the server directory.');
  }
}
