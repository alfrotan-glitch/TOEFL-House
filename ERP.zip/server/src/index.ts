/**
TOEFL House ERP — Express Application Entry Point
============================================================
Bootstraps the entire backend: initializes the database schema,
seeds default rules/workflows, starts the Event Bus, registers
event handlers, and mounts every API router across all Domain-oriented ERP.
*/
import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import http from 'http';
import compression from 'compression';
import rateLimit from 'express-rate-limit';

// ── Database ──────────────────────────────────────────────────────────────
import { initSchema, db } from './db/connection.js';
import { bootstrapRbacCatalog, syncLegacyUserRoles } from './core/rbac/rbac-service.js';
import { bootstrapAcademicCatalog } from './core/academic/bootstrap-catalog.js';

// ── Core Engines ──────────────────────────────────────────────────────────
import { seedDefaultRules } from './core/configuration/rule-engine.js';
import { initializeEventBus } from './core/events/event-bus.js';
import { registerEventHandlers } from './core/events/handlers.js';
import { seedDefaultWorkflowDefinitions } from './utils/workflowSeeds.js';

// ── Middleware ─────────────────────────────────────────────────────────────
import { errorHandler } from './middleware/errorHandler.js';

// ── Security ───────────────────────────────────────────────────────────────
import { assertJwtSecretConfigured } from './utils/auth.js';

// ── Routers (Imports remain exactly the same, omitted for brevity) ─────────
import authRouter from './routes/auth.routes.js';
import { catalogRouter } from './routes/catalog.routes.js';
import { securityRouter } from './routes/security.routes.js';
import usersRouter from './routes/users.routes.js';
import branchesRouter, { partnersRouter, campusesRouter, organizationRouter } from './routes/branches.routes.js';
import visitorsRouter from './routes/visitors.routes.js';
import placementRouter from './routes/placement.routes.js';
import classesRouter, { attendanceRouter } from './routes/classes.routes.js';
import academicRouter from './routes/academic.routes.js';
import studentsRouter, { paymentsRouter } from './routes/students.routes.js';
import offeringsRouter from './routes/offerings.routes.js';
import journeyRouter from './routes/journey.routes.js';
import invoicesRouter from './routes/invoices.routes.js';
import examsRouter from './routes/exams.routes.js';
import teachersRouter, { employeesRouter } from './routes/teachers.routes.js';
import skillsRouter, { classTeacherSkillsRouter } from './routes/skills.routes.js';
import financeRouter from './routes/finance.routes.js';
import booksRouter from './routes/books.routes.js';
import fundingRouter from './routes/funding.routes.js';
import impactRouter from './routes/impact.routes.js';
import workflowsRouter from './routes/workflows.routes.js';
import automationsRouter from './routes/automations.routes.js';
import eventsRouter from './routes/events.routes.js';
import auditRouter, { notificationsRouter } from './routes/audit.routes.js';
import systemSettingsRouter from './routes/settings.routes.js';
import { rulesRouter } from './routes/rules.routes.js';
import bosRouter from './routes/bos.routes.js';
import sessionsRouter from './routes/sessions.routes.js';
import enrollmentRouter from './routes/enrollment.routes.js';
import waitlistRouter from './routes/waitlist.routes.js';
import searchRouter from './routes/search.routes.js';

// ============================================================================
// §1 — INITIALIZATION
// ============================================================================

async function bootstrap(): Promise<void> {
  assertJwtSecretConfigured();

  console.log('Initializing database…');
  initSchema();
  
  bootstrapRbacCatalog(db);
  syncLegacyUserRoles(db);
  
  bootstrapAcademicCatalog(db);
  
  console.log('Seeding default rules and workflows…');
  seedDefaultRules();
  seedDefaultWorkflowDefinitions();
  
  console.log('Starting Event Bus and registering handlers…');
  registerEventHandlers();
  await initializeEventBus();

  console.log('✅ Bootstrap complete.');
}

// ============================================================================
// §2 — EXPRESS APPLICATION
// ============================================================================

const isProduction = process.env.NODE_ENV === 'production';
const app = express();
let isApplicationReady = false;
let startupFailure: string | null = null;
if (process.env.TRUST_PROXY === 'true' && isProduction && !process.env.TRUST_PROXY_HOPS) throw new Error('FATAL: TRUST_PROXY_HOPS must be set when TRUST_PROXY is enabled in production.');
app.set('trust proxy', process.env.TRUST_PROXY === 'true' ? Number(process.env.TRUST_PROXY_HOPS || 1) : false);

// ── Security and performance ──────────────────────────────────────────────
app.use(helmet());
app.use(compression()); // Gzip compression

const corsOriginConfig = process.env.CORS_ORIGIN?.trim();
if (isProduction && !corsOriginConfig) throw new Error('FATAL: CORS_ORIGIN must be explicitly configured in production.');
const effectiveCorsOrigin = corsOriginConfig || 'http://localhost:3000';
const corsOrigins = effectiveCorsOrigin
  .split(',')
  .map((s) => s.trim());
app.use(cors({ origin: corsOrigins, credentials: true }));

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// ── Rate limiting ─────────────────────────────────────────────────────────
// Prevent brute-force attacks on authentication routes
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 50, // Limit each IP to 50 requests per window
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts, please try again later.' }
});

// ── Request logging ───────────────────────────────────────────────────────
app.use((req: Request, _res: Response, next: NextFunction) => {
  if (process.env.NODE_ENV !== 'production') {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// ============================================================================
// §3 — HEALTH CHECK (Database-aware)
// ============================================================================

app.get('/api/health', (_req: Request, res: Response) => {
  try {
    db.prepare('SELECT 1').get();
    const ready = isApplicationReady && !startupFailure;
    res.status(ready ? 200 : 503).json({
      ok: ready, ready, service: 'toefl-house-erp-server', version: '2.0.0',
      database: 'connected', state: ready ? 'ready' : startupFailure ? 'failed' : 'bootstrapping',
      error: startupFailure, time: new Date().toISOString(),
    });
  } catch (_err) {
    res.status(503).json({ ok: false, ready: false, service: 'toefl-house-erp-server', database: 'disconnected', state: 'failed', error: 'Database is not responding' });
  }
});

app.get('/api/ready', (_req: Request, res: Response) => {
  const ready = isApplicationReady && !startupFailure;
  res.status(ready ? 200 : 503).json({ ok: ready, ready, state: startupFailure ? 'failed' : 'bootstrapping', error: startupFailure });
});

// ============================================================================
// §4 — API ROUTES
// ============================================================================

app.use('/api', (req: Request, res: Response, next: NextFunction) => {
  if (isApplicationReady && !startupFailure) return next();
  res.status(503).json({ error: startupFailure || 'Service is still initializing. Please retry shortly.', code: startupFailure ? 'STARTUP_FAILED' : 'SERVICE_NOT_READY' });
});

app.use('/api/auth', authLimiter, authRouter); // Apply rate limiter to auth
app.use('/api/users', usersRouter);
app.use('/api/security', securityRouter);
app.use('/api/organization', organizationRouter);
app.use('/api/campuses', campusesRouter);
app.use('/api/branches', branchesRouter);
app.use('/api/partners', partnersRouter);

app.use('/api/visitors', visitorsRouter);
app.use('/api/placement', placementRouter);

app.use('/api/classes', classesRouter);
app.use('/api/academic', academicRouter);
app.use('/api/offerings', offeringsRouter);
app.use('/api/catalog', catalogRouter);
app.use('/api/attendance', attendanceRouter);
app.use('/api/sessions', sessionsRouter);

app.use('/api/students', studentsRouter);
app.use('/api/enrollments', enrollmentRouter);
app.use('/api/students/:id/journey', journeyRouter);
app.use('/api/classes/:id/waitlist', waitlistRouter);
app.use('/api/payments', paymentsRouter);
app.use('/api/invoices', invoicesRouter);

app.use('/api/exams', examsRouter);

app.use('/api/teachers', teachersRouter);
app.use('/api/employees', employeesRouter);
app.use('/api/skills', skillsRouter);
app.use('/api/class-teacher-skills', classTeacherSkillsRouter);

app.use('/api/finance', financeRouter);
app.use('/api/books', booksRouter);
app.use('/api/funding', fundingRouter);
app.use('/api/impact', impactRouter);

app.use('/api/workflows', workflowsRouter);
app.use('/api/automations', automationsRouter);
app.use('/api/events', eventsRouter);

app.use('/api/audit-logs', auditRouter);
app.use('/api/notifications', notificationsRouter);

app.use('/api/settings', systemSettingsRouter);
app.use('/api/rules', rulesRouter);

app.use('/api/bos', bosRouter);
app.use('/api/search', searchRouter);

// ============================================================================
// §5 — 404 HANDLER & GLOBAL ERROR HANDLER
// ============================================================================

app.use((req: Request, res: Response) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` });
});

app.use(errorHandler);

// ============================================================================
// §6 — SERVER STARTUP & GRACEFUL SHUTDOWN
// ============================================================================

const PORT = Number(process.env.PORT) || 4000;
let server: http.Server | undefined;

function listenOnConfiguredPort(): Promise<void> {
  return new Promise((resolve, reject) => {
    const candidate = app.listen(PORT, '127.0.0.1');
    const onError = (err: NodeJS.ErrnoException) => {
      candidate.removeAllListeners('listening');
      const detail = err.code === 'EADDRINUSE'
        ? `Port ${PORT} is already in use on 127.0.0.1. Stop the existing TOEFL House ERP backend or change PORT in server/.env.`
        : (err.stack || err.message);
      reject(new Error(detail));
    };
    candidate.once('error', onError);
    candidate.once('listening', () => {
      candidate.removeListener('error', onError);
      server = candidate;
      console.log(`[BOOT] HTTP listener active on http://127.0.0.1:${PORT}`);
      resolve();
    });
  });
}

async function start(): Promise<void> {
  try {
    // Bootstrap must complete before readiness is announced and before the
    // listener is opened. This prevents a half-initialized API and makes
    // port conflicts fail deterministically instead of as an uncaught event.
    await bootstrap();
    await listenOnConfiguredPort();
    setupGracefulShutdown();
    isApplicationReady = true;
    startupFailure = null;
    console.log(`✅ TOEFL House ERP ready on http://127.0.0.1:${PORT}`);
  } catch (err) {
    const message = err instanceof Error ? (err.stack || err.message) : String(err);
    startupFailure = message;
    isApplicationReady = false;
    console.error('❌ Fatal error during startup:', message);
    if (server) {
      try { server.close(); } catch { /* listener may already be closed */ }
    }
    setTimeout(() => {
      try { db.close(); } catch { /* database may already be closed during shutdown */ }
      process.exit(1);
    }, 1500).unref();
  }
}

function setupGracefulShutdown() {
  let isShuttingDown = false;

  const shutdown = (signal: string) => {
    if (isShuttingDown) return;
    isShuttingDown = true;

    console.log(`\n${signal} received. Shutting down gracefully...`);

    if (!server) {
      try { db.close(); } catch { /* already closed */ }
      process.exit(0);
      return;
    }

    server.close((err) => {
      if (err) {
        console.error('Error during server close:', err);
        process.exit(1);
      }
      
      console.log('HTTP server closed.');
      try {
        db.close();
        console.log('Database connection closed.');
      } catch (dbErr) {
        console.error('Error closing database:', dbErr);
      }
      
      process.exit(0);
    });

    // Force kill if graceful shutdown fails after 10 seconds
    setTimeout(() => {
      console.error('Forcing shutdown after timeout...');
      process.exit(1);
    }, 10000).unref();
  };

  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

start();