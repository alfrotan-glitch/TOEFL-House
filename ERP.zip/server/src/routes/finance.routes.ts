import { Router } from 'express';
import { db } from '../db/connection.js';
import { authenticate, authorize, requirePermission, resolveBranchScope, canAccessBranchResource, hasLegacyRole } from '../middleware/auth.js';
import { writeAudit } from '../middleware/audit.js';
import { ah, HttpError } from '../middleware/errorHandler.js';
import { id, today } from '../utils/ids.js';
import { addNotification } from '../utils/notifications.js';
import { getNumberSetting, incrementNumberSetting, setSetting } from '../utils/settings.js';
import { decrementMainBalanceIfSufficient, incrementMainBalance, getFinanceAccount } from '../utils/financeAccounts.js';
import { SYSTEM_DEFAULTS } from '../core/configuration/policy-catalog.js';

export const financeRouter = Router();
financeRouter.use(authenticate);

// ── Performance Optimization: Prepared Statements ──────────────────────────
const stmtGetBudgetLineById = db.prepare('SELECT * FROM budget_lines WHERE id = ?');
const stmtUpdateBudgetLineClassify = db.prepare('UPDATE budget_lines SET cost_type = ?, is_marketing = ? WHERE id = ?');
const stmtUpdateBudgetLineCharge = db.prepare('UPDATE budget_lines SET current_amount = current_amount + ?, allocated_amount = allocated_amount + ? WHERE id = ?');
const stmtUpdateBudgetLineClear = db.prepare('UPDATE budget_lines SET current_amount = 0 WHERE id = ?');
const stmtUpdateBudgetLineAddAmount = db.prepare('UPDATE budget_lines SET current_amount = current_amount + ? WHERE id = ?');
const stmtUpdateBudgetLineSubAmount = db.prepare('UPDATE budget_lines SET current_amount = current_amount - ? WHERE id = ?');

const stmtInsertFinTx = db.prepare(
  `INSERT INTO financial_transactions (id, type, category, amount, date, description, reference_id, operator_name, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
);

const stmtGetAllBudgetLines = db.prepare('SELECT * FROM budget_lines ORDER BY id');
const stmtGetBudgetLinesByBranch = db.prepare('SELECT * FROM budget_lines WHERE branch_id = ? ORDER BY id');

const stmtGetAllExpenseRequests = db.prepare('SELECT * FROM expense_requests ORDER BY date DESC');
const stmtGetExpenseRequestsByBranch = db.prepare('SELECT * FROM expense_requests WHERE branch_id = ? ORDER BY date DESC');
const stmtGetExpenseRequestById = db.prepare('SELECT * FROM expense_requests WHERE id = ?');
const stmtInsertExpenseRequest = db.prepare(
  `INSERT INTO expense_requests (id, title, amount, budget_line_id, requester, status, date, branch_id, expense_kind, bill_period, payment_method, notes, auto_approved, requester_user_id, approved_by_user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
);
const stmtUpdateExpenseRequestApproved = db.prepare(
  `UPDATE expense_requests SET status = 'approved', approved_by = ?, approved_by_user_id = ?, reject_reason = NULL WHERE id = ? AND status = 'pending'`
);
const stmtUpdateExpenseRequestRejected = db.prepare(
  `UPDATE expense_requests SET status = 'rejected', reject_reason = ?, approved_by = ?, approved_by_user_id = ? WHERE id = ? AND status = 'pending'`
);

const stmtGetAllTransactions = db.prepare('SELECT * FROM financial_transactions ORDER BY date DESC, rowid DESC LIMIT 500');
const stmtGetTransactionsByBranch = db.prepare('SELECT * FROM financial_transactions WHERE branch_id = ? ORDER BY date DESC, rowid DESC LIMIT 500');

const stmtGetIncomeTotalAll = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income'`);
const stmtGetIncomeTotalByBranch = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income' AND branch_id = ?`);
const stmtGetExpenseTotalAll = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'expense'`);
const stmtGetExpenseTotalByBranch = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'expense' AND branch_id = ?`);
const stmtGetTodayIncomeTotalAll = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income' AND date = ?`);
const stmtGetTodayIncomeTotalByBranch = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income' AND date = ? AND branch_id = ?`);
const stmtGetTodayIncomeForSavingAll = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income' AND date = ?`);
const stmtGetTodayIncomeForSavingByBranch = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'income' AND date = ? AND branch_id = ?`);
const stmtGetTodaySavedTotalAll = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'saving_transfer' AND date = ?`);
const stmtGetTodaySavedTotalByBranch = db.prepare(`SELECT COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE type = 'saving_transfer' AND date = ? AND branch_id = ?`);

/** Safely extract user context required for financial mutations */
function getUserContext(req: import('express').Request) {
  const user = req.user;
  if (!user?.branchId || !user?.fullName || !user?.role) {
    throw new HttpError(403, 'User context is missing for financial operation.');
  }
  return user;
}

/** Ensure budget line exists and caller may access its branch. */
function requireBudgetLine(req: import('express').Request, budgetLineId: string): any {
  const row = stmtGetBudgetLineById.get(budgetLineId) as any;
  if (!row) throw new HttpError(404, 'Budget line not found.');
  
  const { branchId, isAll } = resolveBranchScope(req);
  if (!isAll && branchId && row.branch_id && row.branch_id !== branchId) {
    const user = req.user;
    if (!user) throw new HttpError(401, 'Not authenticated');
    const cross = !!row.branch_id && canAccessBranchResource(req, row.branch_id);
    if (!cross) throw new HttpError(403, 'Budget line belongs to another branch.');
  }
  return row;
}

function mapBudgetLine(row: any) {
  if (!row) return row;
  return {
    id: row.id, name: row.name, allocatedAmount: row.allocated_amount, currentAmount: row.current_amount,
    branchId: row.branch_id, costType: row.cost_type, isMarketing: !!row.is_marketing, purpose: row.purpose,
  };
}

function mapExpenseRequest(row: any) {
  if (!row) return row;
  return {
    id: row.id, title: row.title, amount: row.amount, date: row.date, status: row.status,
    budgetLineId: row.budget_line_id, branchId: row.branch_id, requestedBy: row.requester,
    approvedBy: row.approved_by, approvedByUserId: row.approved_by_user_id, requestedByUserId: row.requester_user_id, rejectReason: row.reject_reason, expenseKind: row.expense_kind,
    paymentMethod: row.payment_method, billPeriod: row.bill_period, notes: row.notes,
  };
}

function mapTransaction(row: any) {
  if (!row) return row;
  return {
    id: row.id, type: row.type, category: row.category, amount: row.amount, date: row.date,
    description: row.description, referenceId: row.reference_id, operatorName: row.operator_name, branchId: row.branch_id,
  };
}

const VALID_EXPENSE_KINDS = new Set(['recurring_bill', 'one_time_purchase', 'maintenance', 'other']);
const VALID_PAYMENT_METHODS = new Set(['cash', 'card', 'bank_transfer']);

function normalizeExpenseMeta(body: any) {
  const expenseKind = body.expenseKind || body.expense_kind || 'other';
  const paymentMethod = body.paymentMethod || body.payment_method || 'cash';
  const billPeriod = body.billPeriod || body.bill_period || null;
  const notes = body.notes || null;
  if (!VALID_EXPENSE_KINDS.has(expenseKind)) throw new HttpError(400, 'Invalid expense kind.');
  if (!VALID_PAYMENT_METHODS.has(paymentMethod)) throw new HttpError(400, 'Invalid payment method.');
  return { expenseKind, paymentMethod, billPeriod, notes };
}

/** Pay an approved amount from a budget line and write the ledger row. */
function payFromBudgetLine(opts: {
  budgetLine: any; amount: number; title: string; date: string; operatorName: string; branchId: string; requestId: string; paymentMethod: string;
}) {
  const category = opts.budgetLine.purpose || 'utility';
  const methodLabel = opts.paymentMethod === 'card' ? 'card' : opts.paymentMethod === 'bank_transfer' ? 'bank transfer' : 'cash';
  
  const updated = db.prepare('UPDATE budget_lines SET current_amount = current_amount - ? WHERE id = ? AND current_amount >= ?').run(opts.amount, opts.budgetLine.id, opts.amount);
  if (updated.changes !== 1) throw new HttpError(409, `Insufficient budget on "${opts.budgetLine.name}" or the balance changed. Please retry.`);
  stmtInsertFinTx.run(
    id('tx'), 'expense', category, opts.amount, opts.date,
    `Expense "${opts.title}" from ${opts.budgetLine.name} (${methodLabel})`,
    opts.requestId, opts.operatorName, opts.branchId
  );
}

// ---------- Overview ----------
financeRouter.get(
  '/overview',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const todayStr = today();

    const income = isAll ? (stmtGetIncomeTotalAll.get() as { total: number }).total : (stmtGetIncomeTotalByBranch.get(branchId) as { total: number }).total;
    const expense = isAll ? (stmtGetExpenseTotalAll.get() as { total: number }).total : (stmtGetExpenseTotalByBranch.get(branchId) as { total: number }).total;
    const todayIncome = isAll ? (stmtGetTodayIncomeTotalAll.get(todayStr) as { total: number }).total : (stmtGetTodayIncomeTotalByBranch.get(todayStr, branchId) as { total: number }).total;

    res.json({
      ...(isAll ? (() => { const a = getFinanceAccount('organization', 'global'); return { mainAccountBalance: a.mainBalance, savingBalance: a.savingBalance }; })() : (() => { const a = getFinanceAccount('branch', branchId!); return { mainAccountBalance: a.mainBalance, savingBalance: a.savingBalance }; })()),
      dailySavingPercent: getNumberSetting('daily_saving_percent', SYSTEM_DEFAULTS.dailySavingPercent),
      expenseAutoApproveThreshold: getNumberSetting('expense_auto_approve_threshold', SYSTEM_DEFAULTS.expenseAutoApproveThreshold),
      totals: {
        income, expense, net: income - expense, todayIncome,
        scope: isAll ? 'organization' : 'branch', branchId: branchId || null,
      },
    });
  })
);

// ---------- Budget lines ----------
financeRouter.get(
  '/budget-lines',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const rows = isAll ? stmtGetAllBudgetLines.all() : stmtGetBudgetLinesByBranch.all(branchId);
    res.json((rows as any[]).map(mapBudgetLine));
  })
);

financeRouter.put(
  '/budget-lines/:id/classify',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const budgetLine = requireBudgetLine(req, req.params.id);
    const { costType, isMarketing } = req.body as { costType?: 'fixed' | 'variable'; isMarketing?: boolean };
    if (costType && !['fixed', 'variable'].includes(costType)) throw new HttpError(400, 'Invalid cost type.');
    
    stmtUpdateBudgetLineClassify.run(
      costType ?? budgetLine.cost_type,
      isMarketing != null ? (isMarketing ? 1 : 0) : budgetLine.is_marketing,
      req.params.id
    );
    writeAudit(req, `Classified budget line "${budgetLine.name}" as ${costType === 'variable' ? 'variable' : 'fixed'} cost`);
    res.json({ ok: true });
  })
);

financeRouter.post(
  '/budget-lines/:id/charge',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const user = getUserContext(req);
    const budgetLine = requireBudgetLine(req, req.params.id);
    const { amount } = req.body;
    if (!amount || amount <= 0) throw new HttpError(400, 'Invalid amount.');
    
    const date = today();
    const tx = db.transaction(() => {
      if (!decrementMainBalanceIfSufficient('organization', 'global', amount)) throw new HttpError(409, 'Insufficient organization treasury balance or the balance changed.');
      stmtUpdateBudgetLineCharge.run(amount, amount, budgetLine.id);
      stmtInsertFinTx.run(
        id('tx'), 'budget_charge', 'utility', amount, date,
        `Budget charge for line "${budgetLine.name}" from the central finance account`,
        budgetLine.id, user.fullName, budgetLine.branch_id || user.branchId
      );
    });
    tx();
    
    addNotification('Budget charge successful', `${amount} AFN deducted from the main account and added to the ${budgetLine.name} budget.`, 'success', user.branchId);
    writeAudit(req, `Allocated and charged budget line ${budgetLine.name} for ${amount} AFN`);
    res.status(201).json({ ok: true });
  })
);

financeRouter.post(
  '/budget-lines/:id/month-end',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const user = getUserContext(req);
    const budgetLine = requireBudgetLine(req, req.params.id);
    const { decision, targetBudgetLineId } = req.body as { decision: 'return' | 'transfer'; targetBudgetLineId?: string };
    const unusedAmount = budgetLine.current_amount;
    
    if (unusedAmount <= 0) throw new HttpError(400, 'The remaining budget for this line is zero and requires no adjustment.');
    const date = today();
    
    if (decision === 'return') {
      const tx = db.transaction(() => {
        stmtUpdateBudgetLineClear.run(budgetLine.id);
        incrementMainBalance('organization', 'global', unusedAmount);
        stmtInsertFinTx.run(
          id('tx'), 'budget_charge', 'utility', unusedAmount, date,
          `Month-end settlement: returning unused budget from line "${budgetLine.name}" to the main account`,
          budgetLine.id, user.fullName, user.branchId
        );
      });
      tx();
      addNotification('Month-end budget settlement', `${unusedAmount} AFN of unused budget from ${budgetLine.name} has been returned to the main account.`, 'success', user.branchId);
      writeAudit(req, `Month-end operation: returned unused budget "${budgetLine.name}" (${unusedAmount} AFN) to the main account`);
    } else if (decision === 'transfer' && targetBudgetLineId) {
      const targetLine = stmtGetBudgetLineById.get(targetBudgetLineId) as any;
      if (!targetLine) throw new HttpError(404, 'Target budget line not found.');
      if (targetLine.branch_id && !canAccessBranchResource(req, targetLine.branch_id)) throw new HttpError(403, 'Target budget line belongs to another branch.');
      if (targetLine.branch_id && budgetLine.branch_id && targetLine.branch_id !== budgetLine.branch_id) throw new HttpError(400, 'Budget transfer must remain within the same branch.');
      
      const tx = db.transaction(() => {
        stmtUpdateBudgetLineClear.run(budgetLine.id);
        stmtUpdateBudgetLineAddAmount.run(unusedAmount, targetBudgetLineId);
        stmtInsertFinTx.run(
          id('tx'), 'saving_transfer', 'utility', unusedAmount, date,
          `Month-end settlement: transferring remaining budget from "${budgetLine.name}" to budget line "${targetLine.name}"`,
          budgetLine.id, user.fullName, user.branchId
        );
      });
      tx();
      addNotification('Month-end budget transfer', `${unusedAmount} AFN of unused budget from "${budgetLine.name}" has been transferred to "${targetLine.name}".`, 'success', user.branchId);
      writeAudit(req, `Month-end operation: transferred remaining budget "${budgetLine.name}" (${unusedAmount} AFN) to "${targetLine.name}"`);
    } else {
      throw new HttpError(400, 'Invalid decision.');
    }
    res.json({ ok: true });
  })
);

// ---------- Expense requests ----------
financeRouter.get(
  '/expense-requests',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const rows = isAll ? stmtGetAllExpenseRequests.all() : stmtGetExpenseRequestsByBranch.all(branchId);
    res.json((rows as any[]).map(mapExpenseRequest));
  })
);

financeRouter.post(
  '/expense-requests',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const user = getUserContext(req);
    const { title, amount, budgetLineId } = req.body;
    const budgetLine = stmtGetBudgetLineById.get(budgetLineId) as any;
    if (budgetLine) requireBudgetLine(req, String(budgetLineId));
    
    if (!title?.trim() || !Number.isFinite(Number(amount)) || Number(amount) <= 0 || !budgetLine) {
      throw new HttpError(400, 'Title, a positive amount, and a valid budget line are required.');
    }
    
    const { expenseKind, paymentMethod, billPeriod, notes } = normalizeExpenseMeta(req.body);
    const newId = id('req');
    stmtInsertExpenseRequest.run(
      newId, title, amount, budgetLineId, user.fullName, 'pending', today(), user.branchId,
      expenseKind, billPeriod, paymentMethod, notes, 0, user.userId, null
    );
    
    addNotification('New expense request', `Expense request "${title}" for ${amount} AFN against budget ${budgetLine.name} is pending approval.`, 'info', user.branchId);
    writeAudit(req, `Created expense request: ${title} for ${amount} AFN against budget ${budgetLine.name}`);
    res.status(201).json({ id: newId, status: 'pending' });
  })
);

financeRouter.post(
  '/operational-payments',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const user = getUserContext(req);
    const { title, amount, budgetLineId, requireApproval } = req.body as {
      title?: string; amount?: number; budgetLineId?: string; requireApproval?: boolean;
    };
    
    const resolvedAmount = Number(amount);
    const budgetLine = stmtGetBudgetLineById.get(budgetLineId) as any;
    if (budgetLine) requireBudgetLine(req, String(budgetLineId));
    if (!title?.trim() || !Number.isFinite(resolvedAmount) || resolvedAmount <= 0 || !budgetLine) {
      throw new HttpError(400, 'Title, a valid amount, and a budget line are required.');
    }

    const { expenseKind, paymentMethod, billPeriod, notes } = normalizeExpenseMeta(req.body);
    const threshold = getNumberSetting('expense_auto_approve_threshold', SYSTEM_DEFAULTS.expenseAutoApproveThreshold);
    const shouldAutoPay = !requireApproval && (resolvedAmount <= threshold || hasLegacyRole(req, 'owner'));

    const date = today();
    const newId = id('req');

    if (!shouldAutoPay) {
      stmtInsertExpenseRequest.run(
        newId, title.trim(), resolvedAmount, budgetLineId, user.fullName, 'pending', date, user.branchId,
        expenseKind, billPeriod, paymentMethod, notes, 0, user.userId, null
      );
      addNotification('Operational expense awaiting approval', `"${title}" (${resolvedAmount} AFN) exceeds the auto-approve threshold (${threshold} AFN) and needs manager/owner approval.`, 'warning', user.branchId);
      writeAudit(req, `Operational expense pending approval: ${title} for ${resolvedAmount} AFN`);
      return res.status(201).json({ id: newId, status: 'pending', autoApproved: false, threshold });
    }

    if (budgetLine.current_amount < resolvedAmount) {
      throw new HttpError(409, `Insufficient balance on budget line "${budgetLine.name}" (remaining: ${budgetLine.current_amount} AFN). Charge the budget first.`);
    }

    const tx = db.transaction(() => {
      stmtInsertExpenseRequest.run(
        newId, title.trim(), resolvedAmount, budgetLineId, user.fullName, 'approved', date, user.branchId,
        expenseKind, billPeriod, paymentMethod, notes, 1, user.userId, user.userId
      );
      db.prepare("UPDATE expense_requests SET approved_by = ? WHERE id = ?").run(user.fullName, newId);
      
      payFromBudgetLine({
        budgetLine, amount: resolvedAmount, title: title.trim(), date, operatorName: user.fullName, branchId: user.branchId, requestId: newId, paymentMethod,
      });
    });
    tx();

    addNotification('Operational expense paid', `"${title}" for ${resolvedAmount} AFN paid from ${budgetLine.name}.`, 'success', user.branchId);
    writeAudit(req, `Operational expense paid: ${title} for ${resolvedAmount} AFN from ${budgetLine.name}`);
    res.status(201).json({ id: newId, status: 'approved', autoApproved: true, threshold });
  })
);

financeRouter.get(
  '/expense-report',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const year = String((req.query as any).year || new Date().getFullYear());
    const month = String((req.query as any).month || 'all');
    const { branchId, isAll } = resolveBranchScope(req);

    const datePattern = month === 'all' ? `${year}-%` : `${year}-${month.padStart(2, '0')}-%`;
    
    const allRequests = isAll 
      ? stmtGetAllExpenseRequests.all() as any[] 
      : stmtGetExpenseRequestsByBranch.all(branchId) as any[];
    
    const filtered = allRequests.filter(er => er.status === 'approved' && er.date.startsWith(datePattern));

    const rowsMap = new Map<string, { budgetLineId: string; budgetLineName: string; purpose: string; costType: string; totalAmount: number; count: number }>();
    const byKindMap = new Map<string, { kind: string; total: number; count: number }>();

    for (const er of filtered) {
      const bl = stmtGetBudgetLineById.get(er.budget_line_id) as any;
      const bId = er.budget_line_id || 'unknown';
      const bName = bl?.name || 'Unknown';
      const purpose = bl?.purpose || 'other';
      const costType = bl?.cost_type || 'variable';
      
      if (!rowsMap.has(bId)) rowsMap.set(bId, { budgetLineId: bId, budgetLineName: bName, purpose, costType, totalAmount: 0, count: 0 });
      const r = rowsMap.get(bId)!;
      r.totalAmount += er.amount;
      r.count++;

      const kind = er.expense_kind || 'other';
      if (!byKindMap.has(kind)) byKindMap.set(kind, { kind, total: 0, count: 0 });
      const k = byKindMap.get(kind)!;
      k.total += er.amount;
      k.count++;
    }

    const rows = Array.from(rowsMap.values()).sort((a, b) => b.totalAmount - a.totalAmount);
    const byKind = Array.from(byKindMap.values()).sort((a, b) => b.total - a.total);
    const totalExpense = rows.reduce((s, r) => s + r.totalAmount, 0);

    res.json({
      year, month, rows, totalExpense, byKind,
      autoApproveThreshold: getNumberSetting('expense_auto_approve_threshold', SYSTEM_DEFAULTS.expenseAutoApproveThreshold),
    });
  })
);

financeRouter.put(
  '/expense-auto-approve-threshold',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const { threshold } = req.body as { threshold?: number };
    if (threshold == null || threshold < 0) throw new HttpError(400, 'Threshold must be a non-negative number.');
    setSetting('expense_auto_approve_threshold', String(Math.round(threshold)));
    writeAudit(req, `Set expense auto-approve threshold to ${Math.round(threshold)} AFN`);
    res.json({ ok: true, threshold: Math.round(threshold) });
  })
);

financeRouter.post(
  '/expense-requests/:id/decide',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const user = getUserContext(req);
    const request = stmtGetExpenseRequestById.get(req.params.id) as any;
    if (!request) throw new HttpError(404, 'Request not found.');
    if (request.status !== 'pending') throw new HttpError(409, `Expense request is already ${request.status} and cannot be decided again.`);
    if (request.requester_user_id && request.requester_user_id === user.userId && !hasLegacyRole(req, 'owner')) throw new HttpError(403, 'Requester and approver must be different users.');
    if (!request.branch_id || !canAccessBranchResource(req, request.branch_id)) throw new HttpError(403, 'Expense request belongs to another branch.');

    const budgetLine = requireBudgetLine(req, String(request.budget_line_id));
    if (budgetLine.branch_id !== request.branch_id) throw new HttpError(409, 'Expense request and budget line belong to different branches.');
    
    const { isApproved, rejectReason } = req.body as { isApproved: boolean; rejectReason?: string };
    if (typeof isApproved !== 'boolean') throw new HttpError(400, 'isApproved must be a boolean.');
    
    if (!isApproved) {
      stmtUpdateExpenseRequestRejected.run(rejectReason || 'Rejected by the course owner', user.fullName, user.userId, request.id);
      addNotification('Budget request rejected', `Request "${request.title}" was rejected by the course owner. Reason: ${rejectReason || 'Not specified'}`, 'alert', user.branchId);
      writeAudit(req, `Rejected expense request: ${request.title}`, { oldValue: 'pending', newValue: 'rejected' });
      return res.json({ status: 'rejected' });
    }
    
    const date = today();
    const tx = db.transaction(() => {
      const updated = stmtUpdateExpenseRequestApproved.run(user.fullName, user.userId, request.id);
      if (updated.changes !== 1) throw new HttpError(409, 'Expense request was already decided.');
      payFromBudgetLine({
        budgetLine, amount: request.amount, title: request.title, date,
        operatorName: user.fullName, branchId: budgetLine.branch_id || user.branchId,
        requestId: request.id, paymentMethod: request.payment_method || 'cash',
      });
    });
    tx();
    
    addNotification('Expense approved and paid', `Request "${request.title}" approved and ${request.amount} AFN paid.`, 'success', user.branchId);
    writeAudit(req, `Approved and paid expense: ${request.title} for ${request.amount} AFN from budget ${budgetLine.name}`);
    res.json({ status: 'approved' });
  })
);

// ---------- Saving engine ----------
financeRouter.post(
  '/saving-engine/run',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const todayStr = today();

    const income = isAll 
      ? (stmtGetTodayIncomeForSavingAll.get(todayStr) as { total: number }).total 
      : (stmtGetTodayIncomeForSavingByBranch.get(todayStr, branchId) as { total: number }).total;
      
    const alreadySaved = isAll 
      ? (stmtGetTodaySavedTotalAll.get(todayStr) as { total: number }).total 
      : (stmtGetTodaySavedTotalByBranch.get(todayStr, branchId) as { total: number }).total;

    res.json({
      ok: true, 
      mode: 'realtime',
      message: 'Savings are applied automatically on each income transaction. Manual bulk run is disabled to prevent double transfers.',
      todayIncome: income, // Fixed: income is already a number
      alreadyTransferredToday: alreadySaved, // Fixed: alreadySaved is already a number
      ...(isAll ? (() => { const a = getFinanceAccount('organization', 'global'); return { mainAccountBalance: a.mainBalance, savingBalance: a.savingBalance }; })() : (() => { const a = getFinanceAccount('branch', branchId!); return { mainAccountBalance: a.mainBalance, savingBalance: a.savingBalance }; })()),
    });
  })
);

financeRouter.put(
  '/saving-engine/settings',
  requirePermission('Budget.Allocate', 'Budget.Edit', 'Expense.Approve'),
  ah(async (req, res) => {
    const { percent } = req.body;
    if (percent == null || percent < 0 || percent > 100) throw new HttpError(400, 'Percentage must be between 0 and 100.');
    setSetting('daily_saving_percent', String(percent));
    writeAudit(req, `Changed daily savings percentage to ${percent}%`);
    res.json({ ok: true });
  })
);

// ---------- Reconciliation ----------
financeRouter.get(
  '/reconciliation',
  requirePermission('Ledger.View', 'Finance.Report'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const paymentParam = isAll ? undefined : branchId;
    const paymentBackedWhere = isAll ? '' : ' AND p.branch_id = ?';
    const ledgerBackedWhere = isAll ? '' : ' AND ft.branch_id = ?';

    const paymentBacked = Number((db.prepare(`SELECT COALESCE(SUM(p.amount),0) AS v FROM payments p WHERE p.status = 'completed' AND p.id IN (SELECT DISTINCT payment_id FROM financial_transactions WHERE payment_id IS NOT NULL)${paymentBackedWhere}`).get(paymentParam) as any).v || 0);
    const ledgerBacked = Number((db.prepare(`SELECT COALESCE(SUM(ft.amount),0) AS v FROM financial_transactions ft WHERE ft.payment_id IS NOT NULL${ledgerBackedWhere}`).get(paymentParam) as any).v || 0);
    const paymentCount = Number((db.prepare(`SELECT COUNT(*) AS v FROM payments p WHERE p.status = 'completed' AND p.id IN (SELECT DISTINCT payment_id FROM financial_transactions WHERE payment_id IS NOT NULL)${paymentBackedWhere}`).get(paymentParam) as any).v || 0);
    const ledgerCount = Number((db.prepare(`SELECT COUNT(*) AS v FROM financial_transactions ft WHERE ft.payment_id IS NOT NULL${ledgerBackedWhere}`).get(paymentParam) as any).v || 0);
    const unmatchedPayments = Number((db.prepare(`SELECT COUNT(*) AS v FROM payments p WHERE p.status = 'completed' AND NOT EXISTS (SELECT 1 FROM financial_transactions ft WHERE ft.payment_id = p.id)${paymentBackedWhere}`).get(paymentParam) as any).v || 0);
    const orphanLedgerRows = Number((db.prepare(`SELECT COUNT(*) AS v FROM financial_transactions ft WHERE ft.payment_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.id = ft.payment_id)${ledgerBackedWhere}`).get(paymentParam) as any).v || 0);

    const mismatchRows = db.prepare(`
      SELECT p.id AS payment_id, p.amount AS payment_amount, COALESCE(SUM(ft.amount),0) AS ledger_amount
      FROM payments p
      LEFT JOIN financial_transactions ft ON ft.payment_id = p.id
      WHERE p.status = 'completed' AND p.id IN (SELECT DISTINCT payment_id FROM financial_transactions WHERE payment_id IS NOT NULL)
      ${paymentBackedWhere}
      GROUP BY p.id
      HAVING ABS(p.amount - COALESCE(SUM(ft.amount),0)) >= 0.01
      ORDER BY p.date DESC
      LIMIT 100
    `).all(paymentParam) as Array<{payment_id: string; payment_amount: number; ledger_amount: number}>;

    res.json({
      scope: isAll ? 'organization' : 'branch',
      branchId: branchId || null,
      paymentBackedTotal: paymentBacked,
      ledgerBackedTotal: ledgerBacked,
      paymentBackedCount: paymentCount,
      ledgerBackedCount: ledgerCount,
      amountVariance: Math.round((paymentBacked - ledgerBacked) * 100) / 100,
      unmatchedPayments,
      orphanLedgerRows,
      mismatchedPayments: mismatchRows.map(r => ({ paymentId: r.payment_id, paymentAmount: r.payment_amount, ledgerAmount: r.ledger_amount, variance: Math.round((Number(r.payment_amount)-Number(r.ledger_amount))*100)/100 })),
      healthy: Math.abs(paymentBacked - ledgerBacked) < 0.01 && unmatchedPayments === 0 && orphanLedgerRows === 0 && mismatchRows.length === 0,
    });
  })
);

// ---------- Ledger (read-only) ----------
financeRouter.get(
  '/transactions',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { from, to, category, type } = req.query as Record<string, string>;
    const { branchId, isAll } = resolveBranchScope(req);
    
    let rows = (isAll ? stmtGetAllTransactions.all() : stmtGetTransactionsByBranch.all(branchId)) as any[];
    
    if (from && to) rows = rows.filter(r => r.date >= from && r.date <= to);
    if (category) rows = rows.filter(r => r.category === category);
    if (type) rows = rows.filter(r => r.type === type);
    
    res.json(rows.map(mapTransaction));
  })
);

financeRouter.get(
  '/pnl',
  requirePermission('Budget.View', 'Payment.View', 'Ledger.View', 'Finance.Report', 'Expense.View'),
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const { from, to } = req.query as { from?: string; to?: string };

    // Safe Dynamic SQL for Date Range PnL using bound parameters
    let sql = `SELECT type, category, COALESCE(SUM(amount), 0) AS total FROM financial_transactions WHERE 1=1`;
    const params: unknown[] = [];
    
    if (!isAll) { 
      sql += ' AND branch_id = ?'; 
      params.push(branchId); 
    }
    if (from) { 
      sql += ' AND date >= ?'; 
      params.push(from); 
    }
    if (to) { 
      sql += ' AND date <= ?'; 
      params.push(to); 
    }
    
    sql += ' GROUP BY type, category ORDER BY type, category';
    
    const finalByCategory = db.prepare(sql).all(...params) as any[];
    
    let income = 0;
    let expense = 0;
    
    for (const row of finalByCategory) {
      if (row.type === 'income') income += row.total;
      if (row.type === 'expense' || row.type === 'budget_charge') expense += row.total;
    }

    res.json({
      from: from || null, 
      to: to || null,
      scope: isAll ? 'organization' : 'branch', 
      branchId: branchId || null,
      income, 
      expense, 
      net: income - expense,
      byCategory: finalByCategory.map((r) => ({ type: r.type, category: r.category, total: r.total })),
    });
  })
);

export default financeRouter;