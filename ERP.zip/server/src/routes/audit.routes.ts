import { Router } from 'express';
import { db } from '../db/connection.js';
import { authenticate, authorize, resolveBranchScope } from '../middleware/auth.js';
import { ah, HttpError } from '../middleware/errorHandler.js';

export const auditRouter = Router();
auditRouter.use(authenticate);

// ── Performance Optimization: Prepared Statements ──────────────────────────
const stmtGetAuditLogsAll = db.prepare('SELECT * FROM audit_logs ORDER BY date DESC, time DESC LIMIT 500');
const stmtGetAuditLogsByBranch = db.prepare('SELECT * FROM audit_logs WHERE branch_id = ? ORDER BY date DESC, time DESC LIMIT 500');

// Only owner & manager can see the full audit trail.
auditRouter.get(
  '/',
  authorize('manager'), // authorize() implicitly allows 'owner' as well
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const rows = isAll ? stmtGetAuditLogsAll.all() : stmtGetAuditLogsByBranch.all(branchId);
    res.json(rows);
  })
);

// ============================================================================
// Notifications Router
// ============================================================================
export const notificationsRouter = Router();
notificationsRouter.use(authenticate);

const stmtGetNotifications = db.prepare(
  `SELECT * FROM notifications 
   WHERE (user_id = ? OR (user_id IS NULL AND (branch_id = ? OR branch_id IS NULL))) 
   ORDER BY date DESC LIMIT 100`
);
const stmtGetNotificationById = db.prepare('SELECT * FROM notifications WHERE id = ?');
const stmtMarkNotificationRead = db.prepare(
  'UPDATE notifications SET read = 1 WHERE id = ? AND (user_id = ? OR user_id IS NULL)'
);
// Do not touch global (user_id IS NULL) notifications, as it affects all users.
const stmtMarkAllUserNotificationsRead = db.prepare(
  'UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0'
);

notificationsRouter.get(
  '/',
  ah(async (req, res) => {
    const userId = req.user?.userId;
    const branchId = req.user?.branchId;
    if (!userId || !branchId) throw new HttpError(403, 'User context is missing.');
    
    // Fetch notifications specifically for this user, or global branch/org notifications
    const rows = stmtGetNotifications.all(userId, branchId);
    res.json(rows);
  })
);

notificationsRouter.patch(
  '/:id/read',
  ah(async (req, res) => {
    const userId = req.user?.userId;
    if (!userId) throw new HttpError(403, 'User context is missing.');
    
    const existing = stmtGetNotificationById.get(req.params.id) as 
      | { id: string; user_id: string | null } 
      | undefined;
      
    if (!existing) throw new HttpError(404, 'Notification not found.');
    if (existing.user_id && existing.user_id !== userId) {
      throw new HttpError(403, 'You do not have permission to modify this notification.');
    }
    
    stmtMarkNotificationRead.run(req.params.id, userId);
    res.json({ ok: true });
  })
);

notificationsRouter.post(
  '/read-all',
  ah(async (req, res) => {
    const userId = req.user?.userId;
    if (!userId) throw new HttpError(403, 'User context is missing.');
    // Global notifications (user_id IS NULL) are left untouched to avoid clearing them for everyone else.
    stmtMarkAllUserNotificationsRead.run(userId);
    res.json({ ok: true });
  })
);

export default auditRouter;