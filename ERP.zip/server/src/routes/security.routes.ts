import { Router } from 'express';
import { db } from '../db/connection.js';
import { authenticate, requirePermission, canAccessBranchResource } from '../middleware/auth.js';
import { writeAudit } from '../middleware/audit.js';
import { ah, HttpError } from '../middleware/errorHandler.js';
import { resolveUserPermissions, syncPrimaryUserRole } from '../core/rbac/rbac-service.js';
import { TAB_PERMISSION_MAP, LEGACY_ROLE_MAP } from '../core/rbac/permission-catalog.js';
import { id } from '../utils/ids.js';
import type { UserRole } from '../utils/auth.js';

export const securityRouter = Router();
securityRouter.use(authenticate);

// ── Performance Optimization: Prepared Statements ──────────────────────────
const stmtGetAllPermissions = db.prepare(`SELECT id, code, resource, action, description, category FROM permissions ORDER BY category, resource, action`);
const stmtGetAllRoles = db.prepare(`SELECT id, code, name, description, is_system AS isSystem, is_active AS isActive, sort_order AS sortOrder FROM roles ORDER BY sort_order, name`);
const stmtGetAllRolePermissions = db.prepare(`SELECT rp.role_id, p.code, p.resource, p.action, p.description, rp.default_scope AS scope FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id ORDER BY p.category, p.code`);

const stmtGetRoleById = db.prepare(`SELECT id, code, name, description, is_system AS isSystem, is_active AS isActive FROM roles WHERE id = ?`);
const stmtGetPermissionsByRoleId = db.prepare(`SELECT p.id AS permissionId, p.code, p.resource, p.action, p.description, p.category, rp.default_scope AS scope FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?`);
const stmtGetRoleCodeById = db.prepare('SELECT id, code FROM roles WHERE id = ?');
const stmtDeleteRolePermissions = db.prepare('DELETE FROM role_permissions WHERE role_id = ?');
const stmtInsertRolePermission = db.prepare('INSERT INTO role_permissions (id, role_id, permission_id, default_scope) VALUES (?, ?, ?, ?)');

const stmtGetUserRoles = db.prepare(`SELECT ur.id, ur.role_id AS roleId, r.code AS roleCode, r.name AS roleName, ur.scope_type AS scopeType, ur.scope_id AS scopeId, ur.is_primary AS isPrimary, ur.assigned_at AS assignedAt, ur.expires_at AS expiresAt FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? ORDER BY ur.is_primary DESC, r.sort_order`);
const stmtGetUserByIdSimple = db.prepare('SELECT id, branch_id AS branchId FROM users WHERE id = ?');
const stmtInsertUserRole = db.prepare(`INSERT INTO user_roles (id, user_id, role_id, scope_type, scope_id, is_primary, assigned_by, assigned_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'), ?)`);
const stmtDeleteUserRole = db.prepare('DELETE FROM user_roles WHERE id = ? AND user_id = ?');
const CANONICAL_USER_ROLES = new Set(['owner', 'manager', 'finance', 'registrar', 'teacher', 'head_of_department', 'counselor', 'donor_manager']);
function legacyRoleForCanonicalCode(roleCode: string): UserRole | null {
  for (const [legacy, canonical] of Object.entries(LEGACY_ROLE_MAP)) {
    
if (canonical === roleCode && CANONICAL_USER_ROLES.has(legacy)) return legacy as UserRole;
  }
  return CANONICAL_USER_ROLES.has(roleCode) ? roleCode as UserRole : null;
}


const stmtGetUserOverrides = db.prepare(`SELECT o.id, o.permission_id AS permissionId, p.code AS permissionCode, o.effect, o.scope_type AS scopeType, o.scope_id AS scopeId, o.reason, o.created_at AS createdAt, o.expires_at AS expiresAt FROM permission_overrides o JOIN permissions p ON p.id = o.permission_id WHERE o.user_id = ? ORDER BY o.created_at DESC`);
const stmtInsertUserOverride = db.prepare(`INSERT INTO permission_overrides (id, user_id, permission_id, effect, scope_type, scope_id, reason, granted_by, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), ?)`);
const stmtGetOverrideById = db.prepare('SELECT id, user_id AS userId, scope_type AS scopeType, scope_id AS scopeId FROM permission_overrides WHERE id = ?');
const stmtDeleteUserOverride = db.prepare('DELETE FROM permission_overrides WHERE id = ?');

/** Safely extracts user context required for mutations */
function requireTargetUserAccess(req: import('express').Request, userId: string) {
  const target = stmtGetUserByIdSimple.get(userId) as { id: string; branchId: string | null } | undefined;
  if (!target) throw new HttpError(404, 'User not found.');
  if (target.branchId && !canAccessBranchResource(req, target.branchId)) {
    throw new HttpError(403, 'User belongs to another branch.');
  }
  return target;
}

function requireScopedAssignment(req: import('express').Request, scopeType: string | undefined, scopeId: string | null | undefined) {
  if (scopeType === 'branch' && scopeId && !canAccessBranchResource(req, scopeId)) {
    throw new HttpError(403, 'Role scope targets a branch outside your access.');
  }
}

function getUserContext(req: import('express').Request) {
  const user = req.user;
  if (!user?.userId) {
    throw new HttpError(403, 'User context is missing for security operation.');
  }
  return user;
}

securityRouter.get('/permissions', requirePermission('Permission.View', 'Role.View'), ah(async (_req, res) => {
  res.json(stmtGetAllPermissions.all());
}));

securityRouter.get('/roles', requirePermission('Role.View'), ah(async (_req, res) => {
  const roles = stmtGetAllRoles.all() as any[];
  const allRolePerms = stmtGetAllRolePermissions.all() as any[];
  const permMap = new Map<string, any[]>();
  for (const p of allRolePerms) {
    if (!permMap.has(p.role_id)) permMap.set(p.role_id, []);
    permMap.get(p.role_id)!.push({ code: p.code, resource: p.resource, action: p.action, description: p.description, scope: p.scope });
  }

  res.json(roles.map((r) => ({ 
    ...r, 
    isSystem: !!r.isSystem, 
    isActive: !!r.isActive, 
    permissions: permMap.get(r.id) || [] 
  })));
}));

securityRouter.get('/roles/:id', requirePermission('Role.View'), ah(async (req, res) => {
  const role = stmtGetRoleById.get(req.params.id) as any;
  if (!role) throw new HttpError(404, 'Role not found.');
  
  const permissions = stmtGetPermissionsByRoleId.all(role.id);
  res.json({ ...role, isSystem: !!role.isSystem, isActive: !!role.isActive, permissions });
}));

securityRouter.put('/roles/:id/permissions', requirePermission('Role.Edit'), ah(async (req, res) => {
  const role = stmtGetRoleCodeById.get(req.params.id) as { id: string; code: string } | undefined;
  if (!role) throw new HttpError(404, 'Role not found.');
  
  const body = req.body as { permissions?: { permissionId: string; scope?: string }[] };
  if (!Array.isArray(body.permissions)) throw new HttpError(400, 'permissions array is required.');
  
  const tx = db.transaction(() => {
    stmtDeleteRolePermissions.run(role.id);
    for (const p of body.permissions!) {
      stmtInsertRolePermission.run(id('rp'), role.id, p.permissionId, p.scope || 'branch');
    }
  });
  tx();
  
  writeAudit(req, `Updated permissions for role ${role.code}`, { newValue: `${body.permissions.length} permissions` });
  res.json({ ok: true, count: body.permissions.length });
}));

securityRouter.get('/users/:userId/roles', requirePermission('User.View', 'Role.View'), ah(async (req, res) => {
  requireTargetUserAccess(req, req.params.userId);
  const rows = stmtGetUserRoles.all(req.params.userId);
  res.json((rows as any[]).map((r) => ({ ...r, isPrimary: !!r.isPrimary })));
}));

securityRouter.post('/users/:userId/roles', requirePermission('User.Edit', 'Role.Edit'), ah(async (req, res) => {
  const user = getUserContext(req);
  const { roleId, scopeType, scopeId, isPrimary, expiresAt } = req.body as any;
  
  if (!roleId) throw new HttpError(400, 'roleId is required.');
  const target = requireTargetUserAccess(req, req.params.userId);
  requireScopedAssignment(req, scopeType || 'branch', scopeId ?? null);
  
  const role = stmtGetRoleCodeById.get(roleId) as { id: string; code: string } | undefined;
  if (!role) throw new HttpError(404, 'Role not found.');
  const primaryLegacyRole = isPrimary ? legacyRoleForCanonicalCode(role.code) : null;
  if (isPrimary) {
    if (!primaryLegacyRole) {
      throw new HttpError(400, 'Only canonical identity roles can be assigned as primary.');
    }
    if ((scopeType || 'branch') !== (role.code === 'owner' ? 'organization' : 'branch')) {
      throw new HttpError(400, 'Primary role scope must match the identity role scope.');
    }
    if (expiresAt) throw new HttpError(400, 'Primary identity roles cannot expire.');
  }
  const tx = db.transaction(() => {
    if (isPrimary) {
      db.prepare('UPDATE user_roles SET is_primary = 0 WHERE user_id = ?').run(req.params.userId);
      db.prepare('UPDATE users SET role = ?, session_version = session_version + 1 WHERE id = ?').run(
        primaryLegacyRole,
        req.params.userId
      );
    }
    const newId = id('ur');
    stmtInsertUserRole.run(newId, req.params.userId, roleId, scopeType || 'branch', scopeId ?? null, isPrimary ? 1 : 0, user.userId, expiresAt ?? null);
    return newId;
  });
  const newId = tx();

  writeAudit(req, `Assigned role ${role.code} to user ${req.params.userId}`);
  res.status(201).json({ id: newId });
}));

securityRouter.delete('/users/:userId/roles/:assignmentId', requirePermission('User.Edit', 'Role.Edit'), ah(async (req, res) => {
  requireTargetUserAccess(req, req.params.userId);
  const assignment = stmtGetUserRoles.get(req.params.userId) as any[];
  const targetAssignment = (assignment as any[]).find((r: any) => r.id === req.params.assignmentId);
  if (!targetAssignment) throw new HttpError(404, 'Assignment not found.');
  if (targetAssignment.isPrimary) throw new HttpError(409, 'The primary identity role cannot be removed. Change the user primary role instead.');
  const result = stmtDeleteUserRole.run(req.params.assignmentId, req.params.userId);
  if (result.changes === 0) throw new HttpError(404, 'Assignment not found.');
  
  writeAudit(req, `Removed role assignment ${req.params.assignmentId}`);
  res.json({ ok: true });
}));

securityRouter.get('/users/:userId/effective-permissions', requirePermission('User.View', 'Permission.View'), ah(async (req, res) => {
  requireTargetUserAccess(req, req.params.userId);
  res.json(resolveUserPermissions(db, req.params.userId));
}));

securityRouter.get('/users/:userId/overrides', requirePermission('Permission.View'), ah(async (req, res) => {
  requireTargetUserAccess(req, req.params.userId);
  res.json(stmtGetUserOverrides.all(req.params.userId));
}));

securityRouter.post('/users/:userId/overrides', requirePermission('Permission.Override'), ah(async (req, res) => {
  const user = getUserContext(req);
  const { permissionId, effect, scopeType, scopeId, reason, expiresAt } = req.body as any;
  requireTargetUserAccess(req, req.params.userId);
  requireScopedAssignment(req, scopeType || 'branch', scopeId ?? null);
  
  if (!permissionId || !effect) throw new HttpError(400, 'permissionId and effect are required.');
  if (effect !== 'grant' && effect !== 'deny') throw new HttpError(400, 'effect must be grant or deny.');
  
  const newId = id('po');
  stmtInsertUserOverride.run(newId, req.params.userId, permissionId, effect, scopeType || 'branch', scopeId ?? null, reason ?? null, user.userId, expiresAt ?? null);
  
  writeAudit(req, `Permission override ${effect} for user ${req.params.userId}`, { newValue: permissionId });
  res.status(201).json({ id: newId });
}));

securityRouter.delete('/overrides/:id', requirePermission('Permission.Override'), ah(async (req, res) => {
  const override = stmtGetOverrideById.get(req.params.id) as { id: string; userId: string; scopeType: string; scopeId: string | null } | undefined;
  if (!override) throw new HttpError(404, 'Override not found.');
  requireTargetUserAccess(req, override.userId);
  requireScopedAssignment(req, override.scopeType, override.scopeId);
  const result = stmtDeleteUserOverride.run(req.params.id);
  if (result.changes === 0) throw new HttpError(404, 'Override not found.');
  writeAudit(req, `Removed permission override ${req.params.id} from user ${override.userId}`);
  res.json({ ok: true });
}));

securityRouter.get('/tab-permissions', ah(async (_req, res) => { 
  res.json(TAB_PERMISSION_MAP); 
}));

securityRouter.get('/me/permissions', ah(async (req, res) => {
  if (req.rbac) {
    return res.json({
      permissions: req.rbac.permissions, 
      permissionCodes: req.rbac.permissionCodes, 
      roles: req.rbac.roles,
      tabAccess: Object.fromEntries(Object.entries(TAB_PERMISSION_MAP).map(([tab, perm]) => [tab, req.rbac!.permissionCodes.has(perm)])),
    });
  }
  res.json({ permissions: [], permissionCodes: [], roles: [], tabAccess: {} });
}));

export default securityRouter;