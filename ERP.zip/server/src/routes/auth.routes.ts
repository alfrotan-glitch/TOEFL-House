import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { db } from '../db/connection.js';
import { hashPassword, verifyPassword, signToken, resolveJwtExpiresInSeconds } from '../utils/auth.js';
import { authenticate } from '../middleware/auth.js';
import { hasRole } from '../core/rbac/rbac-service.js';
import { buildRbacContext, type RbacUserContext } from '../core/rbac/rbac-service.js';
import { TAB_PERMISSION_MAP } from '../core/rbac/permission-catalog.js';
import { writeAudit } from '../middleware/audit.js';
import { ah, HttpError } from '../middleware/errorHandler.js';

export const authRouter = Router();

const SESSION_COOKIE = 'erp_session';
function setSessionCookie(res: import('express').Response, token: string): void {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=${encodeURIComponent(token)}; Max-Age=${resolveJwtExpiresInSeconds()}; Path=/; HttpOnly; SameSite=Strict${secure}`);
}
function clearSessionCookie(res: import('express').Response): void {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${SESSION_COOKIE}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict${secure}`);
}

/** Rate limiter for login: max 10 attempts per 15 minutes per IP (Audit §6.5). */
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ── Performance Optimization: Prepared Statements ──────────────────────────
const stmtGetUserByUsername = db.prepare('SELECT * FROM users WHERE username = ?');
const stmtGetUserByIdSafe = db.prepare('SELECT id, username, full_name, email, role, branch_id, must_change_password, session_version FROM users WHERE id = ?');
const stmtGetUserByIdFull = db.prepare('SELECT * FROM users WHERE id = ?');
const stmtUpdateLastLogin = db.prepare("UPDATE users SET last_login_at = datetime('now') WHERE id = ?");
const stmtUpdatePassword = db.prepare("UPDATE users SET password_hash = ?, must_change_password = 0, session_version = session_version + 1 WHERE id = ?");

// Dummy hash to prevent timing attacks during username enumeration
const DUMMY_HASH = '$2a$10$N9qo8uLOickgx2ZMRZoMy.Mrq8JjCqDwBvVj9oGm6ZvXqJqoYtXa';

interface UserRow {
  id: string;
  username: string;
  password_hash: string;
  full_name: string;
  email: string | null;
  role: 'owner' | 'manager' | 'finance' | 'registrar' | 'teacher' | 'head_of_department' | 'counselor' | 'donor_manager';
  branch_id: string;
  is_active: number;
  must_change_password: number;
  session_version: number;
}

function buildRequiredRbacContext(row: Pick<UserRow, 'id' | 'username' | 'full_name' | 'role' | 'branch_id'>): RbacUserContext {
  try {
    return buildRbacContext(db, row);
  } catch {
    throw new HttpError(503, 'Authorization service is unavailable. Please try again later.');
  }
}

authRouter.post(
  '/login',
  loginLimiter,
  ah(async (req, res) => {
    const { username, password } = req.body as { username?: string; password?: string };
    if (!username || !password) {
      throw new HttpError(400, 'Username and password are required.');
    }

    const row = stmtGetUserByUsername.get(username) as UserRow | undefined;
    const isPasswordValid = row 
      ? await verifyPassword(password, row.password_hash) 
      : await verifyPassword(password, DUMMY_HASH);

    if (!row || !isPasswordValid) {
      throw new HttpError(401, 'Invalid username or password.');
    }

    if (!row.is_active) {
      throw new HttpError(403, 'This account has been deactivated. Contact the system administrator.');
    }

    const token = signToken({
      userId: row.id,
      username: row.username,
      role: row.role,
      branchId: row.branch_id,
      fullName: row.full_name,
      sessionVersion: row.session_version,
    });

    stmtUpdateLastLogin.run(row.id);
    setSessionCookie(res, token);

    req.user = { userId: row.id, username: row.username, role: row.role, branchId: row.branch_id, fullName: row.full_name, sessionVersion: row.session_version };
    writeAudit(req, 'User logged in');

    const rbac = buildRequiredRbacContext({
      id: row.id, username: row.username, full_name: row.full_name, role: row.role, branch_id: row.branch_id,
    });
    
    const tabAccess: Record<string, boolean> = {};
    for (const [tab, perm] of Object.entries(TAB_PERMISSION_MAP)) {
      tabAccess[tab] = rbac.permissionCodes.has(perm) || hasRole(rbac, 'owner');
    }
    
    res.json({
      ...(process.env.NODE_ENV === 'production' ? {} : { token }),
      user: {
        id: row.id, username: row.username, fullName: row.full_name, email: row.email,
        role: row.role, branchId: row.branch_id, mustChangePassword: !!row.must_change_password,
        permissions: Array.from(rbac.permissionCodes), 
        roles: rbac.roles, 
        tabAccess,
      },
    });
  })
);

authRouter.get(
  '/me',
  authenticate,
  ah(async (req, res) => {
    const row = stmtGetUserByIdSafe.get(req.user!.userId) as
      | { id: string; username: string; full_name: string; email: string | null; role: string; branch_id: string; must_change_password: number }
      | undefined;
      
    if (!row) throw new HttpError(404, 'User not found.');
    
    const rbac = req.rbac || buildRequiredRbacContext({
      id: row.id, username: row.username, full_name: row.full_name, role: row.role as UserRow['role'], branch_id: row.branch_id,
    });
    
    const tabAccess: Record<string, boolean> = {};
    for (const [tab, perm] of Object.entries(TAB_PERMISSION_MAP)) {
      tabAccess[tab] = rbac.permissionCodes.has(perm) || hasRole(rbac, 'owner');
    }
    
    res.json({
      id: row.id, username: row.username, fullName: row.full_name, email: row.email,
      role: row.role, branchId: row.branch_id, mustChangePassword: !!row.must_change_password,
      permissions: Array.from(rbac.permissionCodes), 
      roles: rbac.roles, 
      tabAccess,
    });
  })
);

authRouter.post(
  '/logout',
  ah(async (_req, res) => {
    clearSessionCookie(res);
    res.json({ ok: true });
  })
);

authRouter.post(
  '/change-password',
  authenticate,
  ah(async (req, res) => {
    const { currentPassword, newPassword } = req.body as { currentPassword?: string; newPassword?: string };
    if (!newPassword || newPassword.length < 12) {
      throw new HttpError(400, 'New password must be at least 12 characters.');
    }

    const row = stmtGetUserByIdFull.get(req.user!.userId) as UserRow | undefined;
    if (!row) throw new HttpError(404, 'User not found.');
    if (!currentPassword || !(await verifyPassword(currentPassword, row.password_hash))) {
      throw new HttpError(401, 'Current password is incorrect.');
    }
    const newHash = await hashPassword(newPassword);
    stmtUpdatePassword.run(newHash, row.id);
    const nextSessionVersion = row.session_version + 1;
    const renewedToken = signToken({
      userId: row.id, username: row.username, role: row.role, branchId: row.branch_id,
      fullName: row.full_name, sessionVersion: nextSessionVersion,
    });
    setSessionCookie(res, renewedToken);

    writeAudit(req, 'Changed personal password');
    res.json({ ok: true });
  })
);

export default authRouter;