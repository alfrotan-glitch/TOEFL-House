import { Router } from 'express';
import { db } from '../db/connection.js';
import { authenticate, authorize, resolveBranchScope, canAccessBranchResource } from '../middleware/auth.js';
import { writeAudit } from '../middleware/audit.js';
import { ah, HttpError } from '../middleware/errorHandler.js';
import { id, today } from '../utils/ids.js';
import { addNotification } from '../utils/notifications.js';
import { recordIncome } from '../utils/income.js';

export const booksRouter = Router();
booksRouter.use(authenticate);

// ── Performance Optimization: Prepared Statements ──────────────────────────
const stmtGetBookById = db.prepare('SELECT * FROM books WHERE id = ?');
const stmtGetRestockHistoryByBook = db.prepare('SELECT * FROM book_restock_history WHERE book_id = ? ORDER BY date');
const stmtGetBooksByBranch = db.prepare('SELECT * FROM books WHERE branch_id = ? ORDER BY title');
const stmtGetBookByTitleAndType = db.prepare('SELECT * FROM books WHERE branch_id = ? AND is_chapter = ? AND LOWER(TRIM(title)) = ?');
const stmtUpdateBookStockAdd = db.prepare('UPDATE books SET stock = stock + ?, price = ?, purchase_price = ?, entry_date = ? WHERE id = ?');
const stmtInsertRestockHistory = db.prepare('INSERT INTO book_restock_history (id, book_id, date, quantity, price, purchase_price) VALUES (?, ?, ?, ?, ?, ?)');
const stmtInsertBook = db.prepare(
  `INSERT INTO books (id, title, price, purchase_price, stock, is_chapter, branch_id, entry_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
);
const stmtUpdateBook = db.prepare('UPDATE books SET title=?, price=?, stock=?, is_chapter=?, purchase_price=? WHERE id=?');
const stmtDeleteBook = db.prepare('DELETE FROM books WHERE id = ?');
const stmtGetSalesByBranch = db.prepare('SELECT * FROM book_sales WHERE branch_id = ? ORDER BY date DESC');
const stmtGetAllSales = db.prepare('SELECT * FROM book_sales ORDER BY date DESC');
const stmtUpdateBookStockSub = db.prepare('UPDATE books SET stock = stock - ? WHERE id = ? AND branch_id = ? AND stock >= ?');
const stmtInsertBookSale = db.prepare(
  `INSERT INTO book_sales (id, book_id, quantity, total_amount, discount_amount, net_amount, payment_method, status, date, customer_name, student_id, branch_id) VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', ?, ?, ?, ?)`
);
const stmtGetSaleById = db.prepare('SELECT * FROM book_sales WHERE id = ?');
const stmtUpdateSaleStatus = db.prepare("UPDATE book_sales SET status = 'refunded' WHERE id = ?");

/** Ensure book exists and caller may access its branch. */
function requireBook(req: import('express').Request, bookId: string): any {
  const row = stmtGetBookById.get(bookId) as any;
  if (!row) throw new HttpError(404, 'Book not found.');
  
  const { branchId, isAll } = resolveBranchScope(req);
  if (!isAll && branchId && row.branch_id && row.branch_id !== branchId) {
    const user = req.user;
    if (!user) throw new HttpError(401, 'Not authenticated');
    const scopes = req.rbac?.permissions.map((p: { scope: string }) => p.scope) ?? [];
    const cross = !!row.branch_id && canAccessBranchResource(req, row.branch_id);
    if (!cross) throw new HttpError(403, 'Book belongs to another branch.');
  }
  return row;
}

function mapBook(row: any) {
  const restockHistory = stmtGetRestockHistoryByBook.all(row.id) as any[];
  return {
    id: row.id,
    title: row.title,
    price: row.price,
    purchasePrice: row.purchase_price,
    stock: row.stock,
    isChapter: !!row.is_chapter,
    branchId: row.branch_id,
    entryDate: row.entry_date,
    restockHistory: restockHistory.map((r) => ({ date: r.date, quantity: r.quantity, price: r.price, purchasePrice: r.purchase_price })),
  };
}

booksRouter.get(
  '/',
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const rows = isAll 
      ? db.prepare('SELECT * FROM books ORDER BY title').all() 
      : stmtGetBooksByBranch.all(branchId);
    res.json((rows as any[]).map(mapBook));
  })
);

// Adding a book with the same title+type in the same branch aggregates stock (restock) instead of duplicating
booksRouter.post(
  '/',
  authorize('registrar', 'manager', 'finance'),
  ah(async (req, res) => {
    const { title, price, stock, isChapter, entryDate, purchasePrice } = req.body;
    if (!title || price == null || stock == null) throw new HttpError(400, 'Title, price, and quantity are required.');
    if (!Number.isInteger(Number(stock)) || Number(stock) < 0) throw new HttpError(400, 'Stock must be a non-negative integer.');

    const branchId = req.user?.branchId;
    if (!branchId) throw new HttpError(403, 'User branch context is missing.');

    const normalizedTitle = String(title).trim().toLowerCase();
    const existing = stmtGetBookByTitleAndType.get(branchId, isChapter ? 1 : 0, normalizedTitle) as any;

    const targetDate = entryDate || today();
    const finalPurchasePrice = purchasePrice !== undefined ? purchasePrice : Math.round(price * 0.6);

    db.transaction(() => {
      if (existing) {
        stmtUpdateBookStockAdd.run(stock, price, finalPurchasePrice, targetDate, existing.id);
        stmtInsertRestockHistory.run(id('rs'), existing.id, targetDate, stock, price, finalPurchasePrice);
      } else {
        const newId = id('bk');
        stmtInsertBook.run(newId, String(title).trim(), price, finalPurchasePrice, stock, isChapter ? 1 : 0, branchId, targetDate);
        stmtInsertRestockHistory.run(id('rs'), newId, targetDate, stock, price, finalPurchasePrice);
      }
    })();

    writeAudit(req, `Registered or restocked book/chapter: ${title}, adding ${stock} new copies`);
    res.status(201).json({ ok: true });
  })
);

booksRouter.put(
  '/:id',
  authorize('registrar', 'manager', 'finance'),
  ah(async (req, res) => {
    const existing = requireBook(req, req.params.id);
    const { title, price, stock, isChapter, purchasePrice } = req.body;
    if (stock !== undefined && (!Number.isInteger(Number(stock)) || Number(stock) < 0)) {
      throw new HttpError(400, 'Stock must be a non-negative integer.');
    }
    
    stmtUpdateBook.run(
      title ?? existing.title, 
      price ?? existing.price, 
      stock ?? existing.stock,
      isChapter !== undefined ? (isChapter ? 1 : 0) : existing.is_chapter,
      purchasePrice !== undefined ? purchasePrice : existing.purchase_price, 
      req.params.id
    );
    
    writeAudit(req, `Edited book/chapter details: ${existing.title}`);
    res.json({ ok: true });
  })
);

booksRouter.delete(
  '/:id',
  authorize('manager', 'finance'),
  ah(async (req, res) => {
    const existing = requireBook(req, req.params.id);
    stmtDeleteBook.run(req.params.id);
    writeAudit(req, `Deleted book/chapter from system: ${existing.title}`);
    res.json({ ok: true });
  })
);

booksRouter.get(
  '/sales/list',
  ah(async (req, res) => {
    const { branchId, isAll } = resolveBranchScope(req);
    const rows = isAll ? stmtGetAllSales.all() : stmtGetSalesByBranch.all(branchId);
    res.json(rows);
  })
);

booksRouter.post(
  '/:id/sell',
  authorize('registrar', 'manager', 'finance'),
  ah(async (req, res) => {
    const book = requireBook(req, req.params.id);
    const { quantity, customerName, studentId, discountAmount, paymentMethod } = req.body;
    
    if (!quantity || quantity <= 0) throw new HttpError(400, 'Invalid quantity.');
    if (book.stock < quantity) throw new HttpError(409, `Insufficient stock (current stock: ${book.stock})`);

    const user = req.user;
    if (!user?.branchId || !user?.fullName) throw new HttpError(403, 'User context is missing.');
    if (studentId) {
      const student = db.prepare('SELECT branch_id FROM students WHERE id = ?').get(studentId) as { branch_id?: string } | undefined;
      if (!student) throw new HttpError(404, 'Student not found.');
      if (student.branch_id && student.branch_id !== user.branchId) throw new HttpError(403, 'Student belongs to another branch.');
    }

    const totalAmount = book.price * quantity;
    const finalDiscount = Math.max(0, Math.min(Number(discountAmount || 0), totalAmount));
    const netAmount = totalAmount - finalDiscount;
    const categoryType = book.is_chapter ? 'chapter' : 'book';
    const method = paymentMethod || 'cash';
    const methodLabel = ({ cash: 'Cash', card: 'Card', transfer: 'Transfer' } as Record<string, string>)[method] || 'Cash';
    const date = today();
    const newSaleId = id('sale');

    db.transaction(() => {
      const stockUpdate = stmtUpdateBookStockSub.run(quantity, book.id, user.branchId, quantity);
      if (stockUpdate.changes !== 1) throw new HttpError(409, 'Book stock changed or is insufficient. Please retry.');
      stmtInsertBookSale.run(
        newSaleId, book.id, quantity, totalAmount, finalDiscount, netAmount, method, date, 
        customerName || 'Walk-in customer', studentId || null, user.branchId
      );
      recordIncome({
        category: categoryType,
        amount: netAmount,
        date,
        description: `Sold ${quantity} copies of "${book.title}" to ${customerName || 'Walk-in customer'} (${methodLabel}${finalDiscount > 0 ? ` - with discount ${finalDiscount} AFN` : ''})`,
        referenceId: book.id,
        operatorName: user.fullName,
        branchId: user.branchId,
      });
    })();

    addNotification('Book sale successful', `A total of ${quantity} book copies were sold for a net amount of ${netAmount} AFN and recorded in the main account.`, 'success', user.branchId);
    writeAudit(req, `Recorded book sale: ${quantity} copies of ${book.title} for a total of ${totalAmount} AFN (net: ${netAmount} AFN, method: ${methodLabel})`);
    res.status(201).json({ id: newSaleId });
  })
);

booksRouter.post(
  '/sales/:saleId/refund',
  authorize('manager', 'finance'),
  ah(async (req, res) => {
    const sale = stmtGetSaleById.get(req.params.saleId) as any;
    if (!sale) throw new HttpError(404, 'Sale invoice not found.');
    if (!canAccessBranchResource(req, sale.branch_id)) throw new HttpError(403, 'Sale belongs to another branch.');
    if (sale.status === 'refunded') throw new HttpError(409, 'This transaction has already been refunded.');

    const book = stmtGetBookById.get(sale.book_id) as any;
    const refundValue = sale.net_amount != null ? sale.net_amount : sale.total_amount;
    const categoryType = book && book.is_chapter ? 'chapter' : 'book';
    const date = today();

    const user = req.user;
    if (!user?.branchId || !user?.fullName) throw new HttpError(403, 'User context is missing.');

    db.transaction(() => {
      if (book) stmtUpdateBookStockAdd.run(sale.quantity, book.price, book.purchase_price, book.entry_date, book.id);
      stmtUpdateSaleStatus.run(sale.id);
      const refundLedger = db.prepare(
        `INSERT INTO financial_transactions (id, type, category, amount, date, description, reference_id, operator_name, branch_id) VALUES (?, 'income', ?, ?, ?, ?, ?, ?, ?)`
      );
      refundLedger.run(
        id('tx_refund'), categoryType + '_refund', -refundValue, date,
        `Contra-revenue refund for book sale ${sale.id}`, sale.id, user.fullName, user.branchId
      );
    })();

    addNotification('Book refund and return', `Sale invoice #${sale.id} was successfully refunded and ${sale.quantity} copies were returned to stock.`, 'info', user.branchId);
    writeAudit(req, `Refunded book sale invoice: returned ${sale.quantity} copies and refunded ${refundValue} AFN`);
    res.json({ ok: true });
  })
);

export default booksRouter;