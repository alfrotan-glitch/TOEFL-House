import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const failures = [];
const mustExist = [
  'server/src/db/schema.sql',
  'server/src/db/migrations/049_runtime_integrity_hardening.sql',
  'server/src/core/events/event-bus.ts',
  'server/src/core/rbac/rbac-service.ts',
];
for (const file of mustExist) if (!fs.existsSync(path.join(root, file))) failures.push(`Missing required file: ${file}`);

const schema = fs.readFileSync(path.join(root, 'server/src/db/schema.sql'), 'utf8');
const hardeningMigration = fs.readFileSync(path.join(root, 'server/src/db/migrations/049_runtime_integrity_hardening.sql'), 'utf8');
for (const required of ['audit_failures']) {
  if (!schema.includes(required)) failures.push(`Schema hardening missing: ${required}`);
}
for (const required of ['trg_enrollments_branch_integrity_insert', 'trg_payments_branch_integrity_insert', 'trg_book_sales_branch_integrity_insert']) {
  if (!hardeningMigration.includes(required)) failures.push(`Migration hardening missing: ${required}`);
}
const roleTypes = fs.readFileSync(path.join(root, 'src/types.ts'), 'utf8');
const auth = fs.readFileSync(path.join(root, 'src/contexts/AuthContext.tsx'), 'utf8');
for (const role of ['owner','manager','finance','registrar','teacher','head_of_department','counselor','donor_manager']) {
  if (!roleTypes.includes(`| '${role}'`)) failures.push(`Frontend UserRole missing canonical role ${role}`);
  if (!auth.includes(`'${role}'`)) failures.push(`AuthContext role set missing canonical role ${role}`);
}
for (const legacy of ['staff','partner']) {
  if (roleTypes.includes(`| '${legacy}'`)) failures.push(`Legacy frontend role still exposed: ${legacy}`);
  if (auth.includes(`'${legacy}'`)) failures.push(`Legacy frontend role still exposed: ${legacy}`);
}
for (const legacy of ['academic_manager', 'employee', 'student', 'admin']) {
  if (auth.includes(`'${legacy}'`)) failures.push(`Invalid frontend role still present: ${legacy}`);
}
const eventBus = fs.readFileSync(path.join(root, 'server/src/core/events/event-bus.ts'), 'utf8');
if (!eventBus.includes('handlersReady')) failures.push('Event bus readiness guard missing');
if (!eventBus.includes('for (const registration of handlersToRun.sort')) failures.push('Event handlers are not explicitly serialized by priority');
if (failures.length) { console.error('FORENSIC RELEASE AUDIT: FAIL'); for (const f of failures) console.error(` - ${f}`); process.exit(1); }
console.log('FORENSIC RELEASE AUDIT: PASS');
