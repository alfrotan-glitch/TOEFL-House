$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
if (-not (Test-Path 'package.json')) { throw 'package.json not found.' }
if (Test-Path 'node_modules') { Remove-Item 'node_modules' -Recurse -Force }
if (Test-Path 'package-lock.json') {
  npm ci --ignore-scripts --no-audit --no-fund
} else {
  npm install --ignore-scripts --no-audit --no-fund
  if (-not (Test-Path 'package-lock.json')) { throw 'Frontend package-lock.json was not generated.' }
}
Write-Host 'Frontend dependencies installed and lockfile verified.' -ForegroundColor Green
