# TOEFL House ERP

Production-oriented TOEFL House ERP with a React/Vite frontend and Express/SQLite backend.

## One-click first installation on Windows

Double-click `run-all.bat`. For database-only first install, run `bootstrap.bat`. For database-only first install, run `bootstrap.bat`.

The launcher will:

1. Install backend dependencies.
2. Generate `server/.env` automatically when it does not exist or still contains placeholders.
3. Generate a secure first-install JWT secret and owner password.
4. Bootstrap the database and owner account.
5. Start the backend.
6. Start the frontend.

The generated owner username and password are printed by the bootstrap window. Change the owner password after first login.

## Manual commands

Frontend:

```powershell
npm install
npm run typecheck
npm run lint
npm run build
```

Backend:

```powershell
cd server
npm ci
npm run lint
npm test
npm run build
```

First install:

```powershell
cd server
npm run bootstrap
```

## Runtime URLs

- Frontend: http://localhost:3000
- Backend API: http://localhost:4000
- Health: http://localhost:4000/api/health

Production deployments should provide secrets through the environment or a secret manager. Never commit `.env`, database files, or runtime credentials.

## Configuration ownership

Academic curriculum, branch fees, level defaults, rooms, time slots and terms are managed only through the Academic Control Center. Configurable business behavior belongs to the Rule Engine. System Administration contains organization, user, security and operational settings only; it does not duplicate academic policy controls.

Backend policy defaults are centralized in `server/src/core/configuration/policy-catalog.ts` and persisted runtime values are stored in the database.

## First install

Run `bootstrap.bat` once, then start the application with `run-all.bat`. The bootstrap creates `server/.env` automatically when needed, generates secure first-install credentials when the template is used, runs the database bootstrap, and prints the Owner credentials once they are generated. `.env.example` is the only environment template shipped with the project.

## Global workspace search
Authenticated users can press `Ctrl+K` (or `Cmd+K`) to search Students, Visitors, Teachers, Classes, Invoices and Books within their permitted scope. Results route back to the relevant operational module.
