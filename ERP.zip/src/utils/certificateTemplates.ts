import { Student } from '../types';

export type PrintLang = 'en' | 'dari';

interface DisplayExamResult {
  score: number;
  date: string;
  title: string;
  certificateNo?: string;
  subScores?: { reading: number; listening: number; speaking: number; writing: number };
}

function cefrLabel(score: number): string {
  if (score >= 95) return 'C1 (Advanced)';
  if (score >= 72) return 'B2 (Vantage)';
  if (score >= 42) return 'B1 (Threshold)';
  return 'A2 (Waystage)';
}

function openPrintWindow(): Window | null {
  const w = window.open('', '_blank');
  if (!w) {
    alert('Please allow pop-ups in your browser to print.');
    return null;
  }
  return w;
}

/** Official TOEFL simulation report card. Default language: English (staff). Pass lang: 'dari' for parent copies. */
export function printStudentReportCard(
  student: Student,
  res: DisplayExamResult,
  currentAssignedClass: string,
  lang: PrintLang = 'en'
) {
  const printWindow = openPrintWindow();
  if (!printWindow) return;

  const cefr = cefrLabel(res.score);
  const serial = res.certificateNo || `TH-${Math.floor(Math.random() * 90000 + 10000)}`;
  const pass = res.score >= 80;
  const r = res.subScores?.reading ?? 0;
  const l = res.subScores?.listening ?? 0;
  const s = res.subScores?.speaking ?? 0;
  const w = res.subScores?.writing ?? 0;
  const dir = lang === 'dari' ? 'rtl' : 'ltr';
  const font = lang === 'dari' ? "'Tahoma','Segoe UI',sans-serif" : "'Segoe UI',system-ui,sans-serif";

  const t =
    lang === 'dari'
      ? {
          org: 'تافل هاوس کابل',
          orgEn: 'TOEFL House',
          title: 'کارنامه رسمی شبیه‌سازی تافل',
          titleEn: 'OFFICIAL ACADEMIC PERFORMANCE REPORT',
          name: 'نام شاگرد',
          code: 'کد عضویت',
          semester: 'Class / Semester',
          examDate: 'تاریخ آزمون',
          examType: 'نوع آزمون',
          cefr: 'سطح CEFR',
          subs: 'نمرات مهارت‌ها',
          reading: 'خواندن',
          listening: 'شنیدن',
          speaking: 'گفتار',
          writing: 'نوشتار',
          total: 'مجموع',
          result: pass ? 'قبول (PASS)' : 'نیازمند تقویت (FAIL)',
          final: 'تراز نهایی',
          of: 'از ۱۲۰',
          footer:
            'این کارنامه بر اساس استانداردهای ارزیابی تافل هاوس صادر شده و برای تایید سطح علمی شاگرد معتبر است.',
          stamp: 'مهر رسمی',
          examiner: 'ممتحن',
          management: 'مدیریت تافل هاوس',
        }
      : {
          org: 'TOEFL House',
          orgEn: 'International TOEFL Course — Kabul',
          title: 'OFFICIAL ACADEMIC PERFORMANCE REPORT',
          titleEn: 'TOEFL Simulation Report Card',
          name: 'Student name',
          code: 'Student code',
          semester: 'Class / term',
          examDate: 'Exam date',
          examType: 'Exam type',
          cefr: 'CEFR level',
          subs: 'Skill subscores',
          reading: 'Reading',
          listening: 'Listening',
          speaking: 'Speaking',
          writing: 'Writing',
          total: 'Total',
          result: pass ? 'PASS' : 'NEEDS IMPROVEMENT',
          final: 'Final score',
          of: 'of 120',
          footer:
            'Issued by TOEFL House Academic Department under internal assessment standards. Valid for institutional level verification.',
          stamp: 'Official stamp',
          examiner: 'Examiner',
          management: 'Management',
        };

  const html = `<!DOCTYPE html>
<html lang="${lang === 'dari' ? 'fa' : 'en'}" dir="${dir}">
<head>
  <meta charset="utf-8" />
  <title>${t.title} — ${student.fullName}</title>
  <style>
    body { font-family: ${font}; color: #0f172a; margin: 0; padding: 24px; }
    .sheet { max-width: 800px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 16px; padding: 28px; }
    .head { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; border-bottom: 2px solid #312e81; padding-bottom: 16px; }
    .brand { font-size: 22px; font-weight: 800; color: #312e81; }
    .sub { font-size: 12px; color: #64748b; margin-top: 4px; }
    .meta { font-size: 11px; color: #475569; text-align: ${lang === 'dari' ? 'left' : 'right'}; }
    h1 { font-size: 16px; margin: 20px 0 6px; letter-spacing: 0.04em; }
    .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 20px; font-size: 13px; margin: 16px 0; }
    .label { color: #64748b; font-size: 11px; }
    .value { font-weight: 700; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0 20px; font-size: 13px; }
    th, td { border: 1px solid #e2e8f0; padding: 8px; text-align: center; }
    th { background: #f8fafc; font-size: 11px; color: #475569; }
    .score { font-size: 28px; font-weight: 800; color: #312e81; }
    .result { display: inline-block; margin-top: 8px; padding: 4px 10px; border-radius: 999px; font-size: 12px; font-weight: 700;
      background: ${pass ? '#ecfdf5' : '#fff1f2'}; color: ${pass ? '#047857' : '#be123c'}; }
    .foot { margin-top: 24px; font-size: 11px; color: #64748b; line-height: 1.5; }
    .signs { display: flex; justify-content: space-between; margin-top: 36px; font-size: 12px; text-align: center; }
    .signs div { width: 30%; border-top: 1px solid #cbd5e1; padding-top: 8px; }
    @media print { body { padding: 0; } .sheet { border: none; } }
  </style>
</head>
<body>
  <div class="sheet">
    <div class="head">
      <div>
        <div class="brand">${t.org}</div>
        <div class="sub">${t.orgEn}</div>
      </div>
      <div class="meta">
        <div>Serial: ${serial}</div>
        <div>Date: ${res.date}</div>
      </div>
    </div>
    <h1>${t.title}</h1>
    <div class="sub">${t.titleEn}</div>
    <div class="grid">
      <div><div class="label">${t.name}</div><div class="value">${student.fullName}</div></div>
      <div><div class="label">${t.code}</div><div class="value">${student.studentCode}</div></div>
      <div><div class="label">${t.semester}</div><div class="value">${currentAssignedClass || '—'}</div></div>
      <div><div class="label">${t.examDate}</div><div class="value">${res.date}</div></div>
      <div><div class="label">${t.examType}</div><div class="value">${res.title}</div></div>
      <div><div class="label">${t.cefr}</div><div class="value">${cefr}</div></div>
    </div>
    <div class="label">${t.subs}</div>
    <table>
      <thead>
        <tr>
          <th>${t.reading}</th><th>${t.listening}</th><th>${t.speaking}</th><th>${t.writing}</th><th>${t.total}</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${r} / 30</td><td>${l} / 30</td><td>${s} / 30</td><td>${w} / 30</td><td><strong>${res.score} / 120</strong></td>
        </tr>
      </tbody>
    </table>
    <div class="label">${t.final}</div>
    <div class="score">${res.score} <span style="font-size:14px;font-weight:600;color:#64748b">${t.of}</span></div>
    <div class="result">${t.result}</div>
    <p class="foot">${t.footer}</p>
    <div class="signs">
      <div>${t.examiner}</div>
      <div>${t.stamp}</div>
      <div>${t.management}</div>
    </div>
  </div>
  <script>window.onload = function(){ window.print(); }</script>
</body>
</html>`;

  printWindow.document.write(html);
  printWindow.document.close();
}

export interface IdCardDesign {
  primaryColor: string;
  bgStyle: string;
  customMotto: string;
  showQrCode: boolean;
}

/** Student ID card print. Default English; pass lang: 'dari' for local copies. */
export function printStudentIdCard(
  student: Student,
  design: IdCardDesign,
  lang: PrintLang = 'en'
) {
  const printWindow = openPrintWindow();
  if (!printWindow) return;

  const { primaryColor, customMotto, showQrCode } = design;
  let cardGradient = 'linear-gradient(135deg, #1e1b4b 0%, #312e81 100%)';
  if (primaryColor === 'crimson') cardGradient = 'linear-gradient(135deg, #7f1d1d 0%, #b91c1c 100%)';
  else if (primaryColor === 'emerald') cardGradient = 'linear-gradient(135deg, #064e3b 0%, #047857 100%)';
  else if (primaryColor === 'amber') cardGradient = 'linear-gradient(135deg, #78350f 0%, #d97706 100%)';
  else if (primaryColor === 'charcoal') cardGradient = 'linear-gradient(135deg, #111827 0%, #374151 100%)';

  const dir = lang === 'dari' ? 'rtl' : 'ltr';
  const labels =
    lang === 'dari'
      ? {
          org: 'تافل هاوس',
          title: 'کارت هویت شاگرد',
          name: 'Name',
          code: 'کد',
          gender: 'جنسیت',
          registered: 'تاریخ ثبت',
          male: 'Mr',
          female: 'Ms',
          phone: 'تلفن',
        }
      : {
          org: 'TOEFL House',
          title: 'STUDENT IDENTITY CARD',
          name: 'Name',
          code: 'Code',
          gender: 'Gender',
          registered: 'Registered',
          male: 'Male',
          female: 'Female',
          phone: 'Phone',
        };

  const gender =
    student.gender === 'male' ? labels.male : student.gender === 'female' ? labels.female : '—';

  const html = `<!DOCTYPE html>
<html lang="${lang === 'dari' ? 'fa' : 'en'}" dir="${dir}">
<head>
  <meta charset="utf-8" />
  <title>ID — ${student.fullName}</title>
  <style>
    body { font-family: system-ui, Tahoma, sans-serif; background: #f1f5f9; display: flex; justify-content: center; padding: 32px; }
    .card {
      width: 340px; min-height: 210px; border-radius: 16px; color: #fff;
      background: ${cardGradient}; padding: 18px 20px; box-shadow: 0 12px 30px rgba(15,23,42,0.25);
      display: flex; flex-direction: column; justify-content: space-between;
    }
    .top { display: flex; justify-content: space-between; align-items: flex-start; }
    .brand { font-weight: 800; font-size: 14px; letter-spacing: 0.04em; }
    .title { font-size: 10px; opacity: 0.85; margin-top: 2px; }
    .row { font-size: 12px; margin: 4px 0; }
    .k { opacity: 0.75; font-size: 10px; }
    .v { font-weight: 700; }
    .foot { font-size: 10px; opacity: 0.85; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 8px; margin-top: 8px; }
    .qr { width: 48px; height: 48px; background: rgba(255,255,255,0.15); border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 9px; }
    @media print { body { background: #fff; padding: 0; } }
  </style>
</head>
<body>
  <div class="card">
    <div class="top">
      <div>
        <div class="brand">${labels.org}</div>
        <div class="title">${labels.title}</div>
      </div>
      ${showQrCode ? `<div class="qr">${student.studentCode}</div>` : ''}
    </div>
    <div>
      <div class="row"><span class="k">${labels.name}</span><br/><span class="v">${student.fullName}</span></div>
      <div class="row"><span class="k">${labels.code}</span><br/><span class="v">${student.studentCode}</span></div>
      <div class="row"><span class="k">${labels.gender}</span> · <span class="v">${gender}</span>
        &nbsp;·&nbsp; <span class="k">${labels.registered}</span> · <span class="v">${student.registrationDate || '—'}</span>
      </div>
    </div>
    <div class="foot">${customMotto || 'TOEFL House'} · ${labels.phone}: 0799555111</div>
  </div>
  <script>window.onload = function(){ window.print(); }</script>
</body>
</html>`;

  printWindow.document.write(html);
  printWindow.document.close();
}
