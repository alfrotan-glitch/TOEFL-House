import React, { useMemo, useState } from 'react';
import { Users, School, UserPlus, Filter, TrendingUp, DollarSign } from 'lucide-react';
import type { Student, Class, Visitor } from '../../types';
import { formatAFN } from '../../utils/format';

type GenderFilter = 'all' | 'female' | 'male';
type StatusFilter = 'all' | 'active' | 'inactive' | 'graduated';
type ClassGenderFilter = 'all' | 'female' | 'male' | 'mixed';

interface Props {
  students: Student[];
  classes: Class[];
  visitors: Visitor[];
}

export default function OperationsReportView({ students, classes, visitors }: Props) {
  const [gender, setGender] = useState<GenderFilter>('all');
  const [status, setStatus] = useState<StatusFilter>('all');
  const [classGender, setClassGender] = useState<ClassGenderFilter>('all');

  // 1. Filter students based on UI state
  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (status !== 'all' && s.status !== status) return false;
      if (gender !== 'all' && s.gender !== gender) return false;
      return true;
    });
  }, [students, gender, status]);

  // 2. Filter classes based on UI state
  const filteredClasses = useMemo(() => {
    return classes.filter((c) => {
      if (c.status !== 'active') return false;
      const pol = c.genderPolicy || 'mixed';
      if (classGender !== 'all' && pol !== classGender) return false;
      return true;
    });
  }, [classes, classGender]);

  // 3. Aggregate statistics
  const stats = useMemo(() => {
    const activeFemales = students.filter((s) => s.status === 'active' && s.gender === 'female').length;
    const activeMales = students.filter((s) => s.status === 'active' && s.gender === 'male').length;
    const openLeads = visitors.filter((v) => v.status === 'visited' || v.status === 'follow_up').length;
    const converted = visitors.filter((v) => v.status === 'registered').length;
    
    const totalCapacity = filteredClasses.reduce((acc, c) => acc + (c.capacity || 0), 0);
    const totalDebt = filteredStudents.reduce((acc, s) => acc + (s.totalDebt || 0), 0);
    
    const conversionRate = visitors.length > 0 ? Math.round((converted / visitors.length) * 100) : 0;

    return { activeFemales, activeMales, openLeads, converted, totalCapacity, totalDebt, conversionRate };
  }, [students, visitors, filteredClasses, filteredStudents]);

  const selectClass = "border border-slate-200 rounded-lg px-3 py-2 bg-white font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-400 transition-all cursor-pointer";

  return (
    <div className="space-y-6 text-left font-sans" dir="ltr">
      {/* Header & Filters */}
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">Operations Report</h2>
          <p className="text-xs text-slate-500 mt-1">Live enrollment, class capacity, and lead conversion metrics</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-[11px] bg-slate-50 p-2 rounded-xl border border-slate-200">
          <Filter className="w-3.5 h-3.5 text-slate-400 mr-1" />
          <select value={gender} onChange={(e) => setGender(e.target.value as GenderFilter)} className={selectClass}>
            <option value="all">All Genders</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value as StatusFilter)} className={selectClass}>
            <option value="all">All Statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="graduated">Graduated</option>
          </select>
          <select value={classGender} onChange={(e) => setClassGender(e.target.value as ClassGenderFilter)} className={selectClass}>
            <option value="all">All Class Types</option>
            <option value="mixed">Mixed</option>
            <option value="female">Female Only</option>
            <option value="male">Male Only</option>
          </select>
        </div>
      </div>

      {/* KPI Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Students (Filtered)" value={String(filteredStudents.length)} icon={Users} tone="bg-indigo-500/10 text-indigo-600" />
        <StatCard label="Active ♀ / ♂" value={`${stats.activeFemales} / ${stats.activeMales}`} icon={Users} tone="bg-pink-500/10 text-pink-600" />
        <StatCard label="Active Classes" value={String(filteredClasses.length)} sub={`Cap: ${stats.totalCapacity}`} icon={School} tone="bg-violet-500/10 text-violet-600" />
        <StatCard label="Open Leads" value={String(stats.openLeads)} sub={`Conv: ${stats.conversionRate}%`} icon={UserPlus} tone="bg-amber-500/10 text-amber-600" />
      </div>

      {/* Data Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Students Table */}
        <section className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm">
          <header className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Students Directory</h3>
            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-full">{filteredStudents.length} Records</span>
          </header>
          <div className="max-h-[400px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 sticky top-0 z-10">
                <tr>
                  <th className="px-5 py-3 font-semibold uppercase tracking-wider">Name</th>
                  <th className="px-3 py-3 font-semibold uppercase tracking-wider">Status</th>
                  <th className="px-5 py-3 font-semibold uppercase tracking-wider text-right">Outstanding Debt</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.slice(0, 200).map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3 font-semibold text-slate-800">
                      {s.fullName}
                      <span className="block text-[10px] text-slate-400 font-normal capitalize">{s.gender}</span>
                    </td>
                    <td className="px-3 py-3 text-slate-600 capitalize">{s.status}</td>
                    <td className="px-5 py-3 text-right font-mono text-rose-600 font-bold">{formatAFN(s.totalDebt || 0)}</td>
                  </tr>
                ))}
                {filteredStudents.length === 0 && (
                  <tr><td colSpan={3} className="px-5 py-12 text-center text-slate-400">No students match the current filters.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        {/* Classes Table */}
        <section className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden shadow-sm">
          <header className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900">Active Classes</h3>
            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-full">Cap: {stats.totalCapacity}</span>
          </header>
          <div className="max-h-[400px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-200">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 sticky top-0 z-10">
                <tr>
                  <th className="px-5 py-3 font-semibold uppercase tracking-wider">Class Name</th>
                  <th className="px-3 py-3 font-semibold uppercase tracking-wider">Type</th>
                  <th className="px-5 py-3 font-semibold uppercase tracking-wider text-right">Tuition Fee</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredClasses.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-5 py-3 font-semibold text-slate-800">
                      {c.name}
                      <span className="block text-[10px] text-slate-400 font-normal">{c.level}</span>
                    </td>
                    <td className="px-3 py-3">
                      <span className={`text-[10px] font-bold px-2 py-1 rounded-full inline-block ${
                        c.genderPolicy === 'female' ? 'bg-pink-500/10 text-pink-700' 
                        : c.genderPolicy === 'male' ? 'bg-sky-500/10 text-sky-700' 
                        : 'bg-slate-100 text-slate-600'
                      }`}>
                        {c.genderPolicy || 'mixed'}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right font-mono text-slate-700 font-bold">{formatAFN(c.fee || 0)}</td>
                  </tr>
                ))}
                {filteredClasses.length === 0 && (
                  <tr><td colSpan={3} className="px-5 py-12 text-center text-slate-400">No classes match the current filters.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}

// Premium Stat Card Component
function StatCard({
  label, value, sub, icon: Icon, tone,
}: {
  label: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  tone: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-0.5">
      <div className="flex items-start justify-between mb-3">
        <div className={`rounded-xl p-2.5 ${tone}`}>
          <Icon className="w-4 h-4" strokeWidth={2.5} />
        </div>
      </div>
      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-extrabold text-slate-900 font-mono tabular-nums">{value}</p>
      {sub && <p className="mt-1 text-[10px] text-slate-400 font-medium">{sub}</p>}
    </div>
  );
}