/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, Server, ShieldAlert, Cpu, Terminal, RefreshCw } from 'lucide-react';
import { AuditLog } from '../../types';

interface AuditLogViewProps {
  auditLogs: AuditLog[];
}

export default function AuditLogView({ auditLogs }: AuditLogViewProps) {
  return (
    <div className="space-y-6 font-sans text-left" dir="ltr" id="audit-log-view-root">
      {/* Header */}
      <div className="border-b border-slate-200 pb-4">
        <h2 className="text-xl font-extrabold text-slate-900">Central audit & security monitoring (TOEFL House Auditing)</h2>
        <p className="text-xs text-slate-500 mt-1">Track transactions, enrollments, month-end settlements, and user status changes  in real time</p>
      </div>

      {/* Security notice banner */}
      <div className="bg-amber-50 border border-amber-200 text-amber-950 p-4 rounded-2xl text-xs space-y-1.5 leading-relaxed">
        <p className="font-bold flex items-center gap-1.5 text-amber-900">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          Financial data integrity policy
        </p>
        <p>Per TOEFL House security policy, financial records cannot be silently edited or physically deleted. Any finance correction must void the prior document and post a new ledger entry. </p>
      </div>

      {/* Audit Log table layout */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-50 pb-2.5">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
            <Terminal className="w-5 h-5 text-indigo-600" />
            System audit timeline
          </h3>
          <span className="text-[10px] bg-slate-100 px-2.5 py-1 rounded font-mono font-bold text-slate-700">Total events: {auditLogs.length} records</span>
        </div>

        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-slate-500">
                <th className="py-2.5 px-3 font-bold text-slate-700">Operator</th>
                <th className="py-2.5 px-3 font-bold text-slate-700">Action</th>
                <th className="py-2.5 px-3 font-bold text-slate-700">Before</th>
                <th className="py-2.5 px-3 font-bold text-slate-700">After</th>
                <th className="py-2.5 px-3 font-bold text-slate-700">IP address</th>
                <th className="py-2.5 px-3 font-bold text-slate-700">Device / browser</th>
                <th className="py-2.5 px-3 font-bold text-slate-700 font-mono text-left">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-slate-600">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/40">
                  <td className="py-3 px-3 font-semibold text-slate-800">
                    <p className="text-slate-900">{log.operatorName}</p>
                    <p className="text-[10px] text-slate-400 font-mono">ID: #{log.operatorId}</p>
                  </td>
                  <td className="py-3 px-3 text-indigo-600 font-medium">{log.action}</td>
                  <td className="py-3 px-3 font-mono text-slate-400 max-w-xxs truncate" title={log.oldValue}>{log.oldValue || '-'}</td>
                  <td className="py-3 px-3 font-mono text-slate-800 max-w-xxs truncate" title={log.newValue}>{log.newValue || '-'}</td>
                  <td className="py-3 px-3 font-mono text-slate-500">{log.ip}</td>
                  <td className="py-3 px-3 text-slate-400 truncate max-w-xxs" title={log.device}>{log.device}</td>
                  <td className="py-3 px-3 text-left font-mono text-slate-400">
                    <p>{log.date}</p>
                    <p className="text-[9px] mt-0.5">{log.time}</p>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
