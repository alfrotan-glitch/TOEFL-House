import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import type { BudgetLine, FinancialTransaction } from '../../types';
import { formatAFN } from '../../utils/format';

interface Props {
  transactions: FinancialTransaction[];
  budgetLines: BudgetLine[];
  selectedYear: string;
  selectedMonth: string;
}

export default function PnLPanel({ transactions, budgetLines, selectedYear, selectedMonth }: Props) {
  const periodTx = transactions.filter((t) => {
    if (!t.date.startsWith(selectedYear)) return false;
    if (selectedMonth !== 'all' && t.date.substring(5, 7) !== selectedMonth) return false;
    return true;
  });
  const incomeByCat: Record<string, number> = {};
  const expenseByCat: Record<string, number> = {};
  let totalIncome = 0;
  let totalExpense = 0;
  for (const t of periodTx) {
    if (t.type === 'income') {
      totalIncome += t.amount;
      incomeByCat[t.category] = (incomeByCat[t.category] || 0) + t.amount;
    } else if (t.type === 'expense') {
      totalExpense += t.amount;
      expenseByCat[t.category] = (expenseByCat[t.category] || 0) + t.amount;
    }
  }
  const net = totalIncome - totalExpense;
  const incomeRows = Object.entries(incomeByCat).sort((a, b) => b[1] - a[1]);
  const expenseRows = Object.entries(expenseByCat).sort((a, b) => b[1] - a[1]);
  const periodLabel = selectedMonth === 'all' ? selectedYear : `${selectedYear}-${selectedMonth}`;
  const fixedExpense = expenseRows
    .filter(([cat]) => budgetLines.find((b) => b.purpose === cat)?.costType === 'fixed')
    .reduce((s, [, v]) => s + v, 0);
  const variableExpense = totalExpense - fixedExpense;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-l from-indigo-50/40 to-slate-50 border border-slate-200 rounded-2xl p-4 flex flex-col sm:flex-row justify-between gap-3 items-start sm:items-center">
        <div>
          <h3 className="font-extrabold text-slate-900 text-sm">Profit & Loss / Cash overview</h3>
          <p className="text-[10px] text-slate-500 mt-0.5">
            Period <span className="font-mono font-bold">{periodLabel}</span> — computed from database transactions only.
          </p>
        </div>
        <div className={`text-sm font-extrabold font-mono px-3 py-1.5 rounded-xl border ${net >= 0 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
          Net: {net >= 0 ? '+' : ''}{formatAFN(net)}
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total income</p>
          <p className="text-xl font-extrabold font-mono text-emerald-600 mt-1">+{formatAFN(totalIncome)}</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total expenses</p>
          <p className="text-xl font-extrabold font-mono text-rose-600 mt-1">−{formatAFN(totalExpense)}</p>
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Cash net</p>
          <p className={`text-xl font-extrabold font-mono mt-1 ${net >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{net >= 0 ? '+' : ''}{formatAFN(net)}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
          <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-600" /> Income by category</h4>
          {incomeRows.length === 0 ? <p className="text-xs text-slate-400 py-6 text-center">No income in this period.</p> : (
            <div className="space-y-2">{incomeRows.map(([cat, amt]) => (
              <div key={cat} className="flex justify-between items-center text-xs border-b border-slate-50 pb-2">
                <span className="font-bold text-slate-700 capitalize">{cat.replace(/_/g, ' ')}</span>
                <span className="font-mono font-bold text-emerald-600">+{formatAFN(amt)}</span>
              </div>
            ))}</div>
          )}
        </div>
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
          <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-2"><TrendingDown className="w-4 h-4 text-rose-600" /> Expenses by category</h4>
          {expenseRows.length === 0 ? <p className="text-xs text-slate-400 py-6 text-center">No expenses in this period.</p> : (
            <div className="space-y-2">{expenseRows.map(([cat, amt]) => {
              const bl = budgetLines.find((b) => b.purpose === cat);
              return (
                <div key={cat} className="flex justify-between items-center text-xs border-b border-slate-50 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-700 capitalize">{cat.replace(/_/g, ' ')}</span>
                    {bl && <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${bl.costType === 'fixed' ? 'bg-slate-100 text-slate-600' : 'bg-amber-50 text-amber-700'}`}>{bl.costType}</span>}
                  </div>
                  <span className="font-mono font-bold text-rose-600">−{formatAFN(amt)}</span>
                </div>
              );
            })}</div>
          )}
        </div>
      </div>
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
        <h4 className="text-sm font-extrabold text-slate-900 mb-3">Cost structure (from budget classification)</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-50 rounded-xl p-3"><p className="text-slate-500 font-medium">Fixed costs (matched)</p><p className="font-mono font-extrabold text-slate-800 mt-1">{formatAFN(fixedExpense)}</p></div>
          <div className="bg-amber-50/50 rounded-xl p-3"><p className="text-slate-500 font-medium">Variable / other</p><p className="font-mono font-extrabold text-amber-800 mt-1">{formatAFN(variableExpense)}</p></div>
          <div className="bg-emerald-50/50 rounded-xl p-3"><p className="text-slate-500 font-medium">Contribution after variable</p><p className="font-mono font-extrabold text-emerald-700 mt-1">{formatAFN(totalIncome - variableExpense)}</p></div>
        </div>
      </div>
    </div>
  );
}
