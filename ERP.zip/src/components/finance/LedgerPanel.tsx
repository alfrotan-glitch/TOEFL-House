
import React from "react";
import type { FinancialTransaction } from "../../types";
import { formatAFN } from "../../utils/format";

interface Props {
  transactions: FinancialTransaction[];
  selectedYear: string;
  selectedMonth: string;
  timeFrame: "all" | "daily" | "monthly" | "yearly";
  setTimeFrame: (v: "all" | "daily" | "monthly" | "yearly") => void;
  onOpenReport: () => void;
}

export default function LedgerPanel({ transactions, selectedYear, selectedMonth, timeFrame, setTimeFrame, onOpenReport }: Props) {
  const todayStr = new Date().toISOString().split("T")[0];
  const activeYear = selectedYear;
  const activeMonth = selectedMonth === "all" ? todayStr.substring(5, 7) : selectedMonth;
  const activeMonthStr = `${activeYear}-${activeMonth}`;
  const sum = (list: FinancialTransaction[], type: string) => list.filter((t) => t.type === type).reduce((s, t) => s + t.amount, 0);
  const dailyTx = transactions.filter((t) => t.date === todayStr);
  const monthlyTx = transactions.filter((t) => t.date.startsWith(activeMonthStr));
  const yearlyTx = transactions.filter((t) => t.date.startsWith(activeYear));
  const filteredTransactions = transactions.filter((t) => {
    if (!t.date.startsWith(activeYear)) return false;
    if (selectedMonth !== "all" && t.date.substring(5, 7) !== selectedMonth) return false;
    if (timeFrame === "daily") return t.date === todayStr;
    if (timeFrame === "monthly") return t.date.startsWith(activeMonthStr);
    if (timeFrame === "yearly") return t.date.startsWith(activeYear);
    return true;
  });
  const filteredIncome = sum(filteredTransactions, "income");
  const filteredExpense = sum(filteredTransactions, "expense");
  const filteredNet = filteredIncome - filteredExpense;
  const cards = [
    { title: "Daily snapshot", income: sum(dailyTx, "income"), expense: sum(dailyTx, "expense") },
    { title: "Monthly snapshot", income: sum(monthlyTx, "income"), expense: sum(monthlyTx, "expense") },
    { title: "Yearly snapshot", income: sum(yearlyTx, "income"), expense: sum(yearlyTx, "expense") },
  ];
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {cards.map((card) => {
          const net = card.income - card.expense;
          return (
            <div key={card.title} className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm space-y-2 text-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">{card.title}</span>
              <div className="flex justify-between"><span>Income</span><span className="font-mono font-bold text-emerald-600">+{formatAFN(card.income)}</span></div>
              <div className="flex justify-between"><span>Expenses</span><span className="font-mono font-bold text-rose-600">−{formatAFN(card.expense)}</span></div>
              <div className="flex justify-between border-t border-slate-100 pt-2"><span>Net</span><span className={`font-mono font-extrabold ${net >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{net >= 0 ? "+" : ""}{formatAFN(net)}</span></div>
            </div>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-slate-500 font-bold">Quick filter:</span>
          {([["all", "All time"], ["daily", "Daily"], ["monthly", "Monthly"], ["yearly", "Yearly"]] as const).map(([key, label]) => (
            <button key={key} type="button" onClick={() => setTimeFrame(key)} className={`text-[10px] font-bold px-2.5 py-1 rounded-lg ${timeFrame === key ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"}`}>{label}</button>
          ))}
        </div>
        <button type="button" onClick={onOpenReport} className="text-xs font-bold text-indigo-600 hover:bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100">Period statement</button>
      </div>
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <h3 className="text-sm font-extrabold text-slate-900">General ledger</h3>
        <p className="text-[10px] text-slate-400">Data from the database only.</p>
        <div className="flex flex-wrap gap-4 text-xs">
          <span>Period income: <strong className="text-emerald-600 font-mono">+{formatAFN(filteredIncome)}</strong></span>
          <span>Period expenses: <strong className="text-rose-500 font-mono">−{formatAFN(filteredExpense)}</strong></span>
          <span>Net: <strong className={`${filteredNet >= 0 ? "text-emerald-600" : "text-rose-500"} font-mono`}>{filteredNet >= 0 ? "+" : ""}{formatAFN(filteredNet)}</strong></span>
        </div>
        <div className="overflow-x-auto text-xs">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 text-slate-500">
                <th className="py-2.5 px-3 font-bold">Txn ID</th>
                <th className="py-2.5 px-3 font-bold">Type</th>
                <th className="py-2.5 px-3 font-bold">Description</th>
                <th className="py-2.5 px-3 font-bold">Amount</th>
                <th className="py-2.5 px-3 font-bold">Operator</th>
                <th className="py-2.5 px-3 font-bold">Date</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.length === 0 ? (
                <tr><td colSpan={6} className="text-center py-10 text-slate-400">No transactions in this period.</td></tr>
              ) : filteredTransactions.map((tx) => (
                <tr key={tx.id} className="border-b border-slate-50">
                  <td className="py-2.5 px-3 font-mono text-[10px] text-slate-400">{tx.id}</td>
                  <td className="py-2.5 px-3"><span className={`text-[9px] font-black px-1.5 py-0.5 rounded-full ${tx.type === "income" ? "bg-emerald-50 text-emerald-700" : tx.type === "expense" ? "bg-rose-50 text-rose-700" : "bg-indigo-50 text-indigo-700"}`}>{tx.type === "income" ? "Income" : tx.type === "expense" ? "Expense" : "Adjustment"}</span></td>
                  <td className="py-2.5 px-3 text-slate-700 max-w-xs truncate">{tx.description}</td>
                  <td className={`py-2.5 px-3 font-mono font-bold ${tx.type === "income" ? "text-emerald-600" : "text-rose-600"}`}>{tx.type === "income" ? "+" : "−"}{formatAFN(tx.amount)}</td>
                  <td className="py-2.5 px-3 text-slate-500">{tx.operatorName}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-500">{tx.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
