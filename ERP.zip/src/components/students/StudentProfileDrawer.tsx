/**
 * @license SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  CheckCircle2, Award, QrCode, CreditCard, Calendar, AlertCircle,
  Palette, Check, CheckSquare, Printer, Send, GraduationCap, Plus, RotateCcw, X, Pencil, Save, Ban
} from 'lucide-react';
import { Student, Class, Payment, Exam, ExamResult, Attendance } from '../../types';
import { formatAFN } from '../../utils/format';
import { printStudentReportCard, printStudentIdCard } from '../../utils/certificateTemplates';
import StudentJourneyTimeline from './journey/StudentJourneyTimeline';

interface StudentProfileDrawerProps {
  student: Student;
  payments: Payment[];
  attendance: Attendance[];
  exams: Exam[];
  examResults: ExamResult[];
  classes: Class[];
  isOwnerOrManager: boolean;
  isRegistrar: boolean;
  updateStudent: (studentId: string, updatedFields: Partial<Student>) => void;
  updateStudentStatus: (studentId: string, status: 'active' | 'inactive' | 'graduated' | 'suspended') => void;
  issueStudentCard: (studentId: string, cardDesign: { primaryColor: string; bgStyle: string }, notes?: string) => Promise<{ feeCharged: number }>;
  triggerToast: (message: string, type: 'success' | 'error' | 'info') => void;
  onClose: () => void;
  onOpenEnroll: () => void;
  onOpenExtraClass: () => void;
  onOpenRefund: () => void;
  onPayInstallment: (installmentId: string, amount: number) => void;
}

export default function StudentProfileDrawer({
  student, payments, attendance, exams, examResults, classes,
  isOwnerOrManager, isRegistrar, updateStudent, updateStudentStatus, issueStudentCard,
  triggerToast, onClose, onOpenEnroll, onOpenExtraClass, onOpenRefund, onPayInstallment
}: StudentProfileDrawerProps) {
  const [drawerTab, setDrawerTab] = useState<'info' | 'card'>('info');
  const [editingIdentity, setEditingIdentity] = useState(false);
  const [draftPhone, setDraftPhone] = useState(student.phone || '');
  const [draftEmail, setDraftEmail] = useState(student.email || '');
  const [draftAddress, setDraftAddress] = useState(student.addressRegion || '');
  const [draftSchool, setDraftSchool] = useState(student.schoolOrUniversity || '');
  
  // Card Customizer State
  const [primaryColor, setPrimaryColor] = useState<string>('indigo');
  const [bgStyle, setBgStyle] = useState<'waves' | 'solid' | 'modern' | 'dots'>('waves');
  const [customMotto, setCustomMotto] = useState<string>('Where Leaders Learn');
  const [showQrCode, setShowQrCode] = useState<boolean>(true);

  useEffect(() => {
    setDraftPhone(student.phone || '');
    setDraftEmail(student.email || '');
    setDraftAddress(student.addressRegion || '');
    setDraftSchool(student.schoolOrUniversity || '');
    if (student.cardDesign) {
      setPrimaryColor(student.cardDesign.primaryColor || 'indigo');
      setBgStyle(student.cardDesign.bgStyle || 'waves');
      setCustomMotto(student.notes?.includes('Motto:') ? student.notes.split('Motto:')[1].trim().split('\n')[0] : 'Where Leaders Learn');
    }
  }, [student.id]);

  // Financial Calculations
  const totalTuition = student.semesters?.reduce((acc, s) => acc + (Number(s.netFeeAmount ?? s.feeAmount) || 0), 0) || 0;
  const totalPaidFees = payments.filter(p => p.studentId === student.id && (p.category === 'fee' || p.category === 'installment' || p.category === 'refund')).reduce((acc, p) => acc + (Number(p.amount) || 0), 0);
  const remainingDebt = Math.max(0, Number(totalTuition) - Math.max(0, Number(totalPaidFees)));
  const paidPercentage = totalTuition > 0 ? Math.min(100, Math.round((Math.max(0, totalPaidFees) / totalTuition) * 100)) : 100;

  // Attendance Calculations
  const studentAttendance = attendance ? attendance.filter(a => a.targetId === student.id && a.targetType === 'student') : [];
  const totalDays = studentAttendance.length;
  const presentCount = studentAttendance.filter(a => a.status === 'present').length;
  const absentCount = studentAttendance.filter(a => a.status === 'absent').length;
  const leaveCount = studentAttendance.filter(a => a.status === 'leave').length;
  const attendanceRate = totalDays > 0 ? Math.round(((presentCount + leaveCount) / totalDays) * 100) : null;

  // Exam Results Mapping
  const studentExamResults = examResults ? examResults.filter(er => er.studentId === student.id) : [];
  const displayResults = studentExamResults.map(er => {
    const exam = exams ? exams.find(e => e.id === er.examId) : null;
    return { id: er.id, title: exam ? exam.title : 'Assessment result', date: exam ? exam.date : '—', score: Number(er.score || 0) };
  });

  const currentAssignedClass = student.semesters && student.semesters.length > 0 
    ? classes.find(c => c.id === student.semesters![student.semesters!.length - 1].classId)?.name 
    : 'No class assigned';

  const cardThemeClasses: Record<string, string> = {
    indigo: 'from-indigo-950 to-indigo-900 border-indigo-800/40',
    crimson: 'from-rose-950 to-red-900 border-rose-800/40',
    emerald: 'from-emerald-950 to-teal-900 border-emerald-800/40',
    amber: 'from-amber-950 to-orange-900 border-amber-800/40',
    charcoal: 'from-slate-950 to-zinc-900 border-slate-800/40'
  };

  const handleSaveCardDesign = async () => {
    const result = await issueStudentCard(student.id, { primaryColor, bgStyle }, `${student.notes || ''}\n[Motto: ${customMotto}]`);
    triggerToast(result.feeCharged > 0 ? `Smart card issued. Fee ${result.feeCharged} AFN charged.` : 'Card design saved.', 'success');
  };

  return (
    <div className="space-y-6 text-sm text-left animate-in fade-in slide-in-from-bottom-4 duration-300">
      
      {/* Header Info & Actions */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between border-b border-slate-200 pb-4 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-lg">{student.fullName.substring(0, 1)}</div>
          <div>
            <h3 className="font-extrabold text-slate-900 text-base">{student.fullName}</h3>
            <p className="text-xs text-slate-500 mt-0.5">ID: <span className="font-mono font-bold text-indigo-600">{student.studentCode}</span> • {student.currentProgramName || 'Program not assigned'} {student.currentLevelCode ? `• ${student.currentLevelCode}` : ''} • Class: {currentAssignedClass}</p>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-2 items-center">
          {isOwnerOrManager && (
            <div className="flex gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button onClick={() => updateStudentStatus(student.id, 'active')} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer ${student.status === 'active' ? 'bg-emerald-600 text-white' : 'text-slate-600'}`}>Active</button>
              <button onClick={() => updateStudentStatus(student.id, 'inactive')} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer ${student.status === 'inactive' ? 'bg-rose-600 text-white' : 'text-slate-600'}`}>Hold</button>
              <button onClick={() => updateStudentStatus(student.id, 'graduated')} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold cursor-pointer ${student.status === 'graduated' ? 'bg-indigo-600 text-white' : 'text-slate-600'}`}>Graduated</button>
            </div>
          )}
          {isRegistrar && (
            <button onClick={() => setEditingIdentity((v) => !v)} className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100 cursor-pointer">
              <Pencil className="w-3 h-3" /> Edit profile
            </button>
          )}
          {isRegistrar && student.status !== 'suspended' && (
            <button onClick={async () => { try { await updateStudentStatus(student.id, 'suspended'); triggerToast('Student suspended.', 'info'); } catch (err) { triggerToast(err instanceof Error ? err.message : 'Suspend failed.', 'error'); } }} className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-lg bg-amber-50 text-amber-700 border border-amber-100 hover:bg-amber-100 cursor-pointer">
              <Ban className="w-3 h-3" /> Suspend
            </button>
          )}
          {isRegistrar && student.status === 'suspended' && (
            <button onClick={() => updateStudentStatus(student.id, 'active')} className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-100 hover:bg-emerald-100 cursor-pointer">
              <CheckCircle2 className="w-3 h-3" /> Resume
            </button>
          )}
          {isRegistrar && (
            <button onClick={onOpenExtraClass} className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-lg bg-sky-50 text-sky-700 border border-sky-100 hover:bg-sky-100 cursor-pointer">
              <Plus className="w-3 h-3" /> Extra Class
            </button>
          )}
          {isOwnerOrManager && (
            <button onClick={onOpenRefund} className="flex items-center gap-1 text-[10px] font-bold px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-100 hover:bg-rose-100 cursor-pointer">
              <RotateCcw className="w-3 h-3" /> Refund
            </button>
          )}
        </div>
      </div>

      {editingIdentity && (
        <div className="bg-white border border-indigo-100 rounded-2xl p-4 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5"><Pencil className="w-4 h-4 text-indigo-600" /> Quick Profile Edit</h4>
            <button onClick={() => setEditingIdentity(false)} className="text-slate-400 hover:text-slate-700"><X className="w-4 h-4" /></button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input value={draftPhone} onChange={(e) => setDraftPhone(e.target.value)} placeholder="Phone" className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold" />
            <input value={draftEmail} onChange={(e) => setDraftEmail(e.target.value)} placeholder="Email" className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold" />
            <input value={draftAddress} onChange={(e) => setDraftAddress(e.target.value)} placeholder="Address / Region" className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold" />
            <input value={draftSchool} onChange={(e) => setDraftSchool(e.target.value)} placeholder="School / University" className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 text-xs font-semibold" />
          </div>
          <div className="flex justify-end mt-3">
            <button onClick={async () => { try { await updateStudent(student.id, { phone: draftPhone, email: draftEmail, addressRegion: draftAddress, schoolOrUniversity: draftSchool }); setEditingIdentity(false); triggerToast('Student profile updated.', 'success'); } catch (err) { triggerToast(err instanceof Error ? err.message : 'Profile update failed.', 'error'); } }} className="flex items-center gap-1.5 bg-indigo-600 text-white px-3 py-2 rounded-xl text-[10px] font-extrabold"><Save className="w-3 h-3" /> Save changes</button>
          </div>
        </div>
      )}

      {/* Dashboard Widgets */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Finance Widget */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-slate-700 text-xs flex items-center gap-1"><CreditCard className="w-4 h-4 text-indigo-500" /> Finance</span>
            <span className="font-mono font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded text-[10px]">{paidPercentage}% Paid</span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2 mb-3"><div className="bg-indigo-600 h-2 rounded-full" style={{ width: `${paidPercentage}%` }}></div></div>
          <div className="grid grid-cols-3 text-[10px] text-slate-500 font-bold">
            <div><span className="block text-slate-400">Total</span><span className="font-mono text-slate-800 text-xs">{formatAFN(Number(totalTuition||0))}</span></div>
            <div className="text-center"><span className="block text-slate-400">Paid</span><span className="font-mono text-emerald-600 text-xs">{formatAFN(Number(totalPaidFees||0))}</span></div>
            <div className="text-right"><span className="block text-slate-400">Due</span><span className={`font-mono text-xs ${remainingDebt > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>{formatAFN(Number(remainingDebt||0))}</span></div>
          </div>
        </div>

        {/* Attendance Widget */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
          <div className="flex justify-between items-center mb-2">
            <span className="font-bold text-slate-700 text-xs flex items-center gap-1"><Calendar className="w-4 h-4 text-emerald-500" /> Attendance</span>
            <span className={`font-mono font-black px-2 py-0.5 rounded text-[10px] ${attendanceRate === null ? 'bg-slate-100 text-slate-400' : attendanceRate >= 85 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>{attendanceRate === null ? 'N/A' : `${attendanceRate}%`}</span>
          </div>
          {totalDays === 0 ? <p className="text-[10px] text-slate-400 italic py-2">No records yet.</p> : (
            <div className="flex gap-1 mt-2">
              {studentAttendance.slice(-15).map((item, i) => {
                let bg = 'bg-slate-200';
                if (item.status === 'present') bg = 'bg-emerald-500';
                if (item.status === 'absent') bg = 'bg-rose-500';
                if (item.status === 'leave') bg = 'bg-amber-400';
                return <div key={i} className={`w-3 h-3 rounded-sm ${bg}`} title={`${item.date} - ${item.status}`}></div>;
              })}
            </div>
          )}
        </div>

        {/* Alerts Widget */}
        {((attendanceRate !== null && attendanceRate < 85) || remainingDebt > 0) ? (
          <div className="bg-rose-50 border border-rose-200 rounded-2xl p-4 shadow-xs flex flex-col justify-center">
            <div className="flex items-center gap-1.5 text-rose-800 mb-1"><AlertCircle className="w-4 h-4 text-rose-600 shrink-0" /><span className="font-extrabold text-[11px]">Alerts Active</span></div>
            <p className="text-[10px] text-rose-700 leading-relaxed font-semibold">
              {attendanceRate !== null && attendanceRate < 85 && `⚠️ Low attendance (${attendanceRate}%). `}
              {remainingDebt > 0 && `💳 Outstanding debt: ${formatAFN(Number(remainingDebt||0))} AFN.`}
            </p>
          </div>
        ) : (
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 shadow-xs flex flex-col justify-center">
            <div className="flex items-center gap-1.5 text-emerald-800 mb-1"><CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" /><span className="font-extrabold text-[11px]">All Clear</span></div>
            <p className="text-[10px] text-emerald-700 leading-relaxed font-semibold">Student is in good standing. No academic or financial alerts.</p>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 w-full max-w-xs mx-auto">
        <button onClick={() => setDrawerTab('info')} className={`flex-1 text-center py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${drawerTab === 'info' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600'}`}>Academic & Finance</button>
        <button onClick={() => setDrawerTab('card')} className={`flex-1 text-center py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${drawerTab === 'card' ? 'bg-white text-indigo-600 shadow-xs' : 'text-slate-600'}`}>ID Card Studio</button>
      </div>

      {drawerTab === 'info' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Left Column: History & Timelines */}
          <div className="space-y-5">
            {/* Installments & Payments */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
              <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-2 mb-3"><CheckSquare className="w-4 h-4 text-indigo-500" /> Installments & Payments</h4>
              
              {/* Installment Plan */}
              {student.installmentPlan && student.installmentPlan.length > 0 && (
                <div className="space-y-2 mb-4">
                  {student.installmentPlan.map((inst, index) => (
                    <div key={inst.id} className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <span className="text-[10px] font-bold text-slate-500">{inst.dueDate}</span>
                      <span className="flex-1 text-[11px] font-bold text-slate-700">{formatAFN(Number(inst.amount||0))}</span>
                      {inst.status === 'paid' ? (
                        <span className="text-[9px] bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full font-bold">Paid</span>
                      ) : (
                        <button onClick={() => onPayInstallment(inst.id, Number(inst.amount||0))} className="text-[9px] bg-indigo-600 text-white px-2 py-1 rounded-lg font-bold cursor-pointer hover:bg-indigo-700">Settle Now</button>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Payment History */}
              <div className="space-y-2 max-h-48 overflow-y-auto pr-2">
                {payments.filter(p => p.studentId === student.id).map(pay => (
                  <div key={pay.id} className="flex justify-between items-center text-[11px] bg-slate-50 border border-slate-100 p-2.5 rounded-xl">
                    <div><p className="font-black text-slate-800 text-[10px]">{pay.category === 'fee' ? 'Tuition' : pay.category}</p><p className="text-[9px] text-slate-400 font-mono">{pay.date} • {pay.receiptNumber}</p></div>
                    <span className={`font-mono font-black px-2 py-0.5 rounded-lg border text-[10px] ${pay.status === 'refunded' ? 'bg-rose-50 text-rose-600 border-rose-100' : 'bg-emerald-50 text-emerald-600 border-emerald-100'}`}>{pay.status === 'refunded' ? '-' : '+'}{formatAFN(Number(pay.amount||0))}</span>
                  </div>
                ))}
                {payments.filter(p => p.studentId === student.id).length === 0 && <p className="text-[10px] text-slate-400 text-center py-4 italic">No transactions yet.</p>}
              </div>
            </div>

            {/* Exam Progress */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
              <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-2 mb-3"><Award className="w-4 h-4 text-amber-500" /> Exam Progress</h4>
              {displayResults.length === 0 ? <p className="text-[10px] text-slate-400 italic py-4 text-center">No exam results recorded.</p> : (
                displayResults.map(res => (
                  <div key={res.id} className="bg-slate-50 p-3 rounded-xl mb-2">
                    <div className="flex justify-between items-center mb-1">
                      <h5 className="font-bold text-slate-900 text-[10px]">{res.title}</h5>
                      <span className="font-mono font-black text-xs text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded">{res.score} / 120</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-1.5"><div className="bg-indigo-600 h-1.5 rounded-full" style={{ width: `${Math.round((res.score/120)*100)}%` }}></div></div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Right Column: Details & Journey */}
          <div className="space-y-5">
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
              <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-2 mb-3">Identity & Contact</h4>
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 font-semibold">
                <div><span className="text-slate-400 block">Father's Name</span>{student.fatherName || 'N/A'}</div>
                <div><span className="text-slate-400 block">Phone</span><span className="font-mono">{student.phone}</span></div>
                <div><span className="text-slate-400 block">Tazkira No</span><span className="font-mono">{student.tazkiraNo || 'N/A'}</span></div>
                <div><span className="text-slate-400 block">WhatsApp</span><span className="font-mono">{student.whatsapp || 'N/A'}</span></div>
                <div className="col-span-2"><span className="text-slate-400 block">Address</span>{student.addressRegion || 'N/A'}</div>
                <div className="col-span-2"><span className="text-slate-400 block">Emergency Contact</span>{student.emergencyContactName} - <span className="font-mono">{student.emergencyContactPhone}</span></div>
              </div>
              {isRegistrar && (
                <button onClick={onOpenEnroll} className="w-full mt-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold py-2 rounded-xl text-[10px] flex items-center justify-center gap-1 border border-indigo-100 cursor-pointer"><Plus className="w-3 h-3" /> Add New Semester</button>
              )}
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
              <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5 border-b border-slate-100 pb-2 mb-3">Student Journey</h4>
              <StudentJourneyTimeline studentId={student.id} />
            </div>
          </div>
        </div>
      ) : (
        /* ID CARD STUDIO TAB */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          <div className={`bg-gradient-to-br ${cardThemeClasses[primaryColor]} text-white rounded-3xl p-6 shadow-lg border relative overflow-hidden flex flex-col justify-between aspect-[85.6/53.98]`}>
            <div className="flex justify-between items-center border-b border-white/20 pb-2 z-10">
              <span className="font-black text-[14px] text-amber-500 tracking-wider">TOEFL House</span>
              <span className="text-[8px] font-black text-slate-300 text-left leading-normal">STUDENT IDENTITY CARD</span>
            </div>
            <div className="flex gap-4 items-center my-4 z-10">
              <div className="w-16 h-20 rounded-lg bg-white/10 border border-white/30 flex items-center justify-center text-3xl shrink-0">👤</div>
              <div className="flex-1 space-y-1 text-[10px] text-slate-200">
                <div><span className="text-indigo-300 font-bold">Name:</span> <span className="font-extrabold text-white">{student.fullName}</span></div>
                <div><span className="text-indigo-300 font-bold">Code:</span> <span className="font-mono font-bold text-amber-400">{student.studentCode}</span></div>
                <div><span className="text-indigo-300 font-bold">Date:</span> <span className="font-extrabold text-white">{student.registrationDate}</span></div>
              </div>
              {showQrCode && (
                <div className="bg-white p-1 rounded-lg shrink-0"><div className="w-12 h-12 bg-slate-900 flex items-center justify-center"><QrCode className="w-10 h-10 text-white"/></div></div>
              )}
            </div>
            <div className="flex justify-between text-[8px] text-indigo-300 border-t border-white/10 pt-2 z-10">
              <span className="font-semibold text-amber-400/85 italic">{customMotto}</span>
              <span className="font-semibold">TOEFL House Student Services</span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs space-y-4">
            <h4 className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5 border-b border-slate-100 pb-2"><Palette className="w-4 h-4 text-indigo-600" /> Customizer</h4>
            <div>
              <label className="block text-slate-500 font-bold mb-2 text-xs">Theme Color:</label>
              <div className="flex gap-2">
                {[{k:'indigo',l:'Navy',cls:'bg-indigo-800'},{k:'crimson',l:'Burgundy',cls:'bg-rose-800'},{k:'emerald',l:'Emerald',cls:'bg-emerald-800'},{k:'amber',l:'Gold',cls:'bg-amber-700'}].map(c => (
                  <button key={c.k} onClick={() => setPrimaryColor(c.k)} className={`flex-1 py-2 rounded-lg text-[10px] font-bold text-white ${c.cls} ${primaryColor === c.k ? 'ring-2 ring-indigo-500 scale-105' : 'opacity-80'}`}>{c.l}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-slate-500 font-bold mb-2 text-xs">Footer Tagline:</label>
              <input type="text" value={customMotto} onChange={(e) => setCustomMotto(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 font-bold text-slate-800 text-xs" />
            </div>
            <div className="flex gap-2 pt-2">
              <button onClick={handleSaveCardDesign} className="flex-1 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold py-2.5 rounded-xl text-xs cursor-pointer">Save Template</button>
              <button onClick={() => printStudentIdCard(student, { primaryColor, bgStyle, customMotto, showQrCode })} className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold py-2.5 rounded-xl text-xs cursor-pointer flex items-center justify-center gap-1"><Printer className="w-4 h-4" /> Print ID</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}